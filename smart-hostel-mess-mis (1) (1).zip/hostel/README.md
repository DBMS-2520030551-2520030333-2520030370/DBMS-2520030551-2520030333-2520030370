# Smart Hostel and Mess Administration Management Information System

A working implementation of the project described in the KL University report *"Smart Hostel and Mess
Administration Management Information System"*. It centralises student records, room allocation, hostel fees,
attendance, mess administration, complaints, notices and dashboards in one web application.

The project is built on the distributed architecture of the supplied *Society Management Platform*
(API gateway + independent services + single-page dashboard). The society domain (residents, flats, visitors,
amenities) was replaced with the hostel and mess domain, and the security model was tightened.

Runs on Node.js 18+ with **no npm dependencies to install**.

## Quick start

```bash
npm run dev          # starts the 6 services and the gateway
```

Open <http://localhost:4000> and use one of the demo accounts:

| Role | Email | Password |
| --- | --- | --- |
| Admin (hostel administrator) | `admin@hostel.test` | `admin123` |
| Mess staff | `mess@hostel.test` | `mess123` |
| Student | `aarav@student.test` | `student123` |

Other scripts:

```bash
npm run check        # syntax-check every JavaScript file
npm run test:smoke   # starts the system and runs 40 end-to-end checks (auth, rules, RBAC, frontend)
npm run reset:data   # regenerate demo data with dates relative to today
```

## What each role can do

| Module | Admin | Mess staff | Student |
| --- | --- | --- | --- |
| Student management | Register, approve, search, mark vacated | View list | Own profile |
| Room management | Add rooms, allocate/vacate, maintenance flag | - | Sees own room |
| Hostel fees | Raise fees, record payments, receipts | - | View own fees and receipts |
| Attendance | Mark daily (bulk), review leave requests | - | View own %, request leave |
| Mess | Edit weekly menu, meal demand, record meals served | Same as admin | View menu, register/cancel meals |
| Complaints | Log, move through workflow | Review and update | Submit and track own |
| Notices | Publish | Read | Read, mark notifications read |
| Dashboard | Full overview and service health | Mess overview | Personal summary |

Access rules are enforced in the API gateway, not just hidden in the UI (`gateway/server.js`).
A student can never read or change another student's records.

## Business rules implemented

* A room can never exceed its capacity, cannot be allocated while under maintenance, and a student can hold only one active allocation.
* Phone numbers, roll numbers and emails are validated and unique; passwords are stored as salted scrypt hashes.
* Fees are unique per student, type and term; amounts must be positive; a pending fee past its due date is reported **overdue**.
* Fee payment is all-or-nothing (snapshot and rollback) and generates a receipt number; a fee cannot be paid twice.
* Attendance is unique per student per day, cannot be marked for a future date, and reports an attendance percentage.
* Leave requests validate dates and reject overlaps with an active request.
* Meal registration requires a scheduled meal, blocks past dates and duplicates, and feeds a **meal demand** report (food requirement per meal).
* Complaint workflow: Pending, Assigned, In Progress, Resolved, with an activity trail.
* Each service is isolated: if one is down, the dashboard still loads the others.

## Architecture

```
Browser (frontend/)  ->  API Gateway :4000  (auth, RBAC, routing, overview)
                              |
   +--------------+-----------+-----------+--------------+-------------+
   Student :4101   Fee :4102   Complaint   Attendance     Mess :4105   Notification
   students,       fees,       :4103       :4104          menu,        :4106
   rooms,          payments,   complaints  attendance,    registrations notices,
   allocations     receipts                leaves         meal demand  notifications
```

Every service owns its own data file (`services/<name>/db.json`, created from `seed.json`).
See `docs/architecture.md` and `docs/api.md`.

## Relational database (MySQL)

The report specifies MySQL. `docs/database-schema.sql` is the complete MySQL schema for the same design:
14 tables with primary/foreign keys, unique and check constraints, indexes, 4 views, 2 triggers
(room capacity, no future attendance) and 1 stored procedure (atomic fee payment). It has been loaded and its
rules tested on a live server. The demo runtime uses JSON files so it runs anywhere without setup; to move to MySQL, replace the
`readJson/writeJson` calls in `shared/service-kit.js` with queries against these tables.

## Mapping to the project report

| Report section | Where it is implemented |
| --- | --- |
| 2.4 Functional requirements | All modules in `services/` and `frontend/app.js` |
| 2.5 Non-functional (security, integrity) | Gateway RBAC, hashed passwords, validation, `docs/database-schema.sql` |
| 3 Technology stack (HTML5, CSS3, JavaScript, backend, MySQL) | `frontend/`, Node.js services, `docs/database-schema.sql` |
| 4 System architecture (presentation / backend / database layers) | `frontend/` -> `gateway/` + `services/` -> per-service data stores |
| 5.2 ER diagram / relationships | Tables and foreign keys in `docs/database-schema.sql` |
| 5.4 Role-based access design | `proxyRules` in `gateway/server.js`, Access Matrix in the Architecture screen |
| 5.5 Validation and data integrity | Service handlers, DB constraints and triggers |
| 6.x Implementation modules | `student-service`, `fee-service`, `attendance-service`, `mess-service`, `complaint-service`, `notification-service` |
| 8 Testing | `npm run test:smoke` (functional, integration and role tests) |
| 9 Deployment | `docker-compose.yml`, `.env.example` |
| Future scope (mobile app, online payments, biometrics/QR, AI demand prediction, SMS/email, cloud) | Not implemented, as stated in the report; meal-demand data is the base for prediction |

## Project structure

```
frontend/             Single-page dashboard (index.html, app.js, styles.css)
gateway/server.js     API gateway: auth, RBAC, routing, overview aggregation
shared/service-kit.js Tiny router, JSON store, HTTP helpers, password hashing
services/             student, fee, complaint, attendance, mess, notification services
scripts/              start-all, generate-seed, reset-data, smoke-test
docs/                 api.md, architecture.md, database-schema.sql
```

## Docker

```bash
docker compose up --build
```
