# REST API Reference

All browser calls go through the gateway at `http://localhost:4000` and need `Authorization: Bearer <token>`
(except login and health). Roles: `admin`, `mess`, `student`. Students only ever see or change their own records;
the gateway applies that filter and stamps their `studentId` on writes.

## Auth and gateway

| Method | Route | Purpose | Roles |
| --- | --- | --- | --- |
| POST | `/api/auth/login` | `{email, password}` returns `{token, user}` | public |
| GET | `/api/auth/me` | Current token payload | all |
| GET | `/api/health`, `/api/service-status` | Gateway and service health | public |
| GET | `/api/overview` | Aggregated dashboard metrics | admin, mess |

## Student service

| Method | Route | Purpose | Write roles |
| --- | --- | --- | --- |
| GET | `/api/students?q=&status=` | List students (student role: own record only) | - |
| GET | `/api/students/:id` | Student profile | - |
| POST | `/api/students` | Register (validates phone, unique roll no and email) | admin |
| PATCH | `/api/students/:id` | Update details or status | admin |
| GET | `/api/rooms?block=&status=` | Rooms with live occupancy | - |
| POST | `/api/rooms` | Add room (capacity 1-6) | admin |
| PATCH | `/api/rooms/:roomNo` | Change capacity or maintenance flag | admin |
| GET | `/api/allocations?studentId=&roomNo=&status=` | Allocation history | - |
| POST | `/api/allocations` | `{studentId, roomNo}`; rejects full, maintenance, already-allocated | admin |
| PATCH | `/api/allocations/:id/vacate` | Close an allocation | admin |

## Fee service (admin, student read-only)

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/fees?studentId=&status=&feeType=&term=` | Fee ledger (pending, overdue, paid) |
| POST | `/api/fees` | Raise a fee `{studentId, feeType, amount, term, dueDate}` |
| PATCH | `/api/fees/:id` | Edit an unpaid fee |
| GET | `/api/payments` | Payment history |
| GET | `/api/payments/pending/:studentId` | Pending amount for a student |
| POST | `/api/payments/pay` | `{studentId, feeId, method}`, atomic, returns receipt |
| GET | `/api/receipts/:id` | Receipt by payment id or receipt number |

## Attendance service

| Method | Route | Purpose | Write roles |
| --- | --- | --- | --- |
| GET | `/api/attendance?studentId=&date=&from=&to=&status=` | Attendance records | - |
| POST | `/api/attendance` | Mark one student/day (upsert) | admin |
| POST | `/api/attendance/bulk` | `{date, records:[{studentId,status}]}` | admin |
| GET | `/api/attendance/summary?date=` | Counts for a day | admin |
| GET | `/api/attendance/summary/:studentId` | Attendance percentage | admin |
| GET | `/api/leaves` | Leave requests | - |
| POST | `/api/leaves` | `{fromDate, toDate, reason, destination}` | student, admin |
| PATCH | `/api/leaves/:id/status` | Approve or reject | admin |

## Mess service

| Method | Route | Purpose | Write roles |
| --- | --- | --- | --- |
| GET | `/api/menu?day=&mealType=` | Weekly menu | - |
| POST / PATCH | `/api/menu`, `/api/menu/:id` | Create or edit a slot | admin, mess |
| GET | `/api/registrations` | Meal registrations | - |
| POST | `/api/registrations` | `{date, mealType}` (future/today, scheduled meal, no duplicates) | student, admin, mess |
| PATCH | `/api/registrations/:id/cancel` | Cancel own registration | student, admin, mess |
| GET / POST | `/api/meal-attendance` | Meals served (flags walk-ins) | admin, mess |
| GET | `/api/demand?date=` | Registered vs served per meal (food requirement) | admin, mess |

## Complaint service

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/complaints` | List (students: own) |
| POST | `/api/complaints` | Submit `{category, description, priority}` (all roles) |
| PATCH | `/api/complaints/:id/assign` | Assign (admin, mess) |
| PATCH | `/api/complaints/:id/status` | Pending, Assigned, In Progress, Resolved (admin, mess) |

## Notification service

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/notices` | Notice board (all roles) |
| POST / PATCH | `/api/notices`, `/api/notices/:id` | Publish or edit (admin) |
| GET | `/api/notifications` | Notifications (students: own) |
| POST | `/api/notifications` | Create (admin) |
| PATCH | `/api/notifications/:id/read` | Mark own notification read |
