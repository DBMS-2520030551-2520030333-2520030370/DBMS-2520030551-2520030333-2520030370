# Architecture

The system follows the three-layer design in the project report (presentation, backend, database),
with the backend split into independent services behind an API gateway.

```
Web client (HTML5 / CSS3 / JavaScript)
        |
API Gateway :4000   authentication, role-based authorisation, routing, dashboard aggregation
        |
   +-- Student Service :4101       users, rooms, allocations
   +-- Fee Service :4102           fees, payments, receipts
   +-- Complaint Service :4103     complaints and activity trail
   +-- Attendance Service :4104    daily attendance, leave requests
   +-- Mess Service :4105          menu, meal registration, meals served, demand
   +-- Notification Service :4106  notices, notifications
```

## Layer responsibilities (report chapter 4)

* **Presentation**: `frontend/`, role-specific navigation and forms; no database access.
* **Backend**: gateway plus services enforce validation and business rules; the browser never sees credentials of the data stores.
* **Database**: one store per service (JSON files in the demo, MySQL schema in `database-schema.sql`).

## Security

* Login is verified by the Student Service against scrypt-hashed passwords; the gateway issues an HMAC-signed token (8 hours).
* Every `/api/*` route except login and health needs a valid token.
* The gateway holds a rule table (`proxyRules`) listing which roles may read and write each resource. Students are further
  limited to their own records: the gateway forces `studentId=<their id>` on reads and writes.
* Owning services double-check ownership for actions addressed by record id (cancelling a meal, marking a notification read).

## Cross-service communication

Fee Service calls Student Service before raising a fee or recording a payment to verify the student exists.
The payment keeps a snapshot and restores it if any step fails, matching the `sp_record_payment` stored procedure in the SQL schema.

## Fault isolation

`/api/service-status` reports each service. `/api/overview` and the frontend loader tolerate a failed service: the rest of
the dashboard loads and a message names the missing data.

## Production upgrade path

Replace JSON stores with MySQL (schema provided), move token signing to a standard JWT library with refresh tokens,
add rate limiting at the gateway, and add a message broker for SMS/email notifications (report future scope).
