-- MySQL 8 schema for the Smart Hostel and Mess Administration Management Information System.
-- The runnable demo keeps each service's data in JSON files (database-per-service, no install needed);
-- this script is the relational design deliverable and the target for a production MySQL deployment.
-- Load with:  mysql -u root -p < docs/database-schema.sql

CREATE DATABASE IF NOT EXISTS smart_hostel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_hostel;

-- ---------------------------------------------------------------- Users, rooms, allocation (student-service)
CREATE TABLE users (
  id             VARCHAR(20)  PRIMARY KEY,
  roll_no        VARCHAR(20)  NOT NULL UNIQUE,
  name           VARCHAR(100) NOT NULL,
  phone          CHAR(10)     NOT NULL,
  email          VARCHAR(120) NOT NULL UNIQUE,
  password_hash  VARCHAR(200) NOT NULL,
  role           ENUM('admin','mess','student') NOT NULL DEFAULT 'student',
  course         VARCHAR(80)  NOT NULL,
  study_year     TINYINT      NOT NULL DEFAULT 1,
  guardian_name  VARCHAR(100),
  guardian_phone VARCHAR(15),
  status         ENUM('active','pending','vacated') NOT NULL DEFAULT 'active',
  joined_date    DATE         NOT NULL,
  CONSTRAINT chk_phone CHECK (phone REGEXP '^[0-9]{10}$'),
  CONSTRAINT chk_year  CHECK (study_year BETWEEN 0 AND 6)
) ENGINE=InnoDB;

CREATE TABLE rooms (
  room_no           VARCHAR(10) PRIMARY KEY,
  block             CHAR(1)     NOT NULL,
  floor_no          TINYINT     NOT NULL,
  capacity          TINYINT     NOT NULL,
  room_type         VARCHAR(20) NOT NULL DEFAULT 'Standard',
  under_maintenance BOOLEAN     NOT NULL DEFAULT FALSE,
  CONSTRAINT chk_capacity CHECK (capacity BETWEEN 1 AND 6)
) ENGINE=InnoDB;

CREATE TABLE allocations (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  student_id   VARCHAR(20) NOT NULL,
  room_no      VARCHAR(10) NOT NULL,
  allocated_on DATE        NOT NULL,
  vacated_on   DATE        NULL,
  status       ENUM('Active','Vacated') NOT NULL DEFAULT 'Active',
  -- generated column: only one ACTIVE allocation per student (NULL values never collide in a UNIQUE index)
  active_student VARCHAR(20) AS (CASE WHEN status = 'Active' THEN student_id END) STORED,
  UNIQUE KEY uq_one_active_room (active_student),
  KEY idx_alloc_room (room_no, status),
  CONSTRAINT fk_alloc_student FOREIGN KEY (student_id) REFERENCES users(id),
  CONSTRAINT fk_alloc_room    FOREIGN KEY (room_no)    REFERENCES rooms(room_no)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- Fees (fee-service)
CREATE TABLE fees (
  id           VARCHAR(30) PRIMARY KEY,
  student_id   VARCHAR(20) NOT NULL,
  fee_type     ENUM('Hostel Rent','Mess Charges','Security Deposit','Electricity','Fine','Other') NOT NULL,
  amount       DECIMAL(10,2) NOT NULL,
  term         VARCHAR(20) NOT NULL,
  due_date     DATE        NOT NULL,
  status       ENUM('pending','paid') NOT NULL DEFAULT 'pending',
  payment_date DATETIME    NULL,
  receipt_no   VARCHAR(40) NULL,
  notes        VARCHAR(200),
  UNIQUE KEY uq_fee_once (student_id, fee_type, term),
  KEY idx_fee_status_due (status, due_date),
  CONSTRAINT chk_amount CHECK (amount > 0),
  CONSTRAINT fk_fee_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id           VARCHAR(30) PRIMARY KEY,
  fee_id       VARCHAR(30) NOT NULL UNIQUE,
  student_id   VARCHAR(20) NOT NULL,
  amount       DECIMAL(10,2) NOT NULL,
  method       ENUM('UPI','Cash','Card','Bank Transfer') NOT NULL,
  payment_date DATETIME    NOT NULL,
  receipt_no   VARCHAR(40) NOT NULL UNIQUE,
  recorded_by  VARCHAR(20) NOT NULL,
  CONSTRAINT fk_pay_fee     FOREIGN KEY (fee_id)      REFERENCES fees(id),
  CONSTRAINT fk_pay_student FOREIGN KEY (student_id)  REFERENCES users(id),
  CONSTRAINT fk_pay_by      FOREIGN KEY (recorded_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- Attendance and leave (attendance-service)
CREATE TABLE attendance (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  student_id  VARCHAR(20) NOT NULL,
  att_date    DATE        NOT NULL,
  status      ENUM('Present','Absent','Late','On Leave') NOT NULL,
  remark      VARCHAR(200),
  marked_by   VARCHAR(20),
  UNIQUE KEY uq_att_day (student_id, att_date),
  KEY idx_att_date (att_date),
  CONSTRAINT fk_att_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE leave_requests (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  student_id  VARCHAR(20) NOT NULL,
  from_date   DATE        NOT NULL,
  to_date     DATE        NOT NULL,
  reason      VARCHAR(200) NOT NULL,
  destination VARCHAR(100),
  status      ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  reviewed_by VARCHAR(20),
  created_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_leave_dates CHECK (to_date >= from_date),
  CONSTRAINT fk_leave_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- Mess (mess-service)
CREATE TABLE mess_menu (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  day_name  ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  meal_type ENUM('Breakfast','Lunch','Snacks','Dinner') NOT NULL,
  items     VARCHAR(250) NOT NULL,
  is_veg    BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE KEY uq_menu_slot (day_name, meal_type)
) ENGINE=InnoDB;

CREATE TABLE meal_registrations (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL,
  meal_date  DATE        NOT NULL,
  meal_type  ENUM('Breakfast','Lunch','Snacks','Dinner') NOT NULL,
  status     ENUM('Registered','Cancelled') NOT NULL DEFAULT 'Registered',
  created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_meal_reg (student_id, meal_date, meal_type),
  KEY idx_meal_demand (meal_date, meal_type, status),
  CONSTRAINT fk_reg_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE meal_attendance (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL,
  meal_date  DATE        NOT NULL,
  meal_type  ENUM('Breakfast','Lunch','Snacks','Dinner') NOT NULL,
  served_by  VARCHAR(20),
  served_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_meal_served (student_id, meal_date, meal_type),
  CONSTRAINT fk_meal_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- Complaints and notices
CREATE TABLE complaints (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    VARCHAR(20) NOT NULL,
  category      ENUM('Room','Mess','Water','Electricity','Cleaning','Internet','Security','Other') NOT NULL,
  description   TEXT        NOT NULL,
  priority      ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  status        ENUM('Pending','Assigned','In Progress','Resolved') NOT NULL DEFAULT 'Pending',
  assigned_to   VARCHAR(80),
  created_at    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at   DATETIME    NULL,
  KEY idx_complaint_status (status, priority),
  CONSTRAINT fk_complaint_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE complaint_activity (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  message      VARCHAR(250) NOT NULL,
  at_time      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_activity_complaint FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notices (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  admin_id    VARCHAR(20) NOT NULL,
  title       VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  category    VARCHAR(30) NOT NULL DEFAULT 'General',
  priority    ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  audience    VARCHAR(40) NOT NULL DEFAULT 'All Students',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_on  DATE NULL,
  CONSTRAINT fk_notice_admin FOREIGN KEY (admin_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  student_id  VARCHAR(20) NOT NULL,
  title       VARCHAR(120) NOT NULL,
  message     VARCHAR(250) NOT NULL,
  channel     VARCHAR(20) NOT NULL DEFAULT 'In App',
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_student FOREIGN KEY (student_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- Views for dashboards and reports
CREATE VIEW v_room_occupancy AS
SELECT r.room_no, r.block, r.capacity, r.under_maintenance,
       COUNT(a.id) AS occupied,
       r.capacity - COUNT(a.id) AS vacant,
       CASE WHEN r.under_maintenance THEN 'Maintenance'
            WHEN COUNT(a.id) >= r.capacity THEN 'Full' ELSE 'Available' END AS room_status
FROM rooms r
LEFT JOIN allocations a ON a.room_no = r.room_no AND a.status = 'Active'
GROUP BY r.room_no, r.block, r.capacity, r.under_maintenance;

CREATE VIEW v_pending_fees AS
SELECT f.id, u.roll_no, u.name, f.fee_type, f.amount, f.term, f.due_date,
       CASE WHEN f.due_date < CURDATE() THEN 'overdue' ELSE 'pending' END AS effective_status
FROM fees f JOIN users u ON u.id = f.student_id
WHERE f.status = 'pending';

CREATE VIEW v_attendance_summary AS
SELECT u.id AS student_id, u.roll_no, u.name,
       SUM(a.status = 'Present') AS present_days,
       SUM(a.status = 'Late')    AS late_days,
       SUM(a.status = 'Absent')  AS absent_days,
       ROUND(100 * SUM(a.status IN ('Present','Late')) / NULLIF(SUM(a.status <> 'On Leave'), 0), 1) AS attendance_pct
FROM users u JOIN attendance a ON a.student_id = u.id
GROUP BY u.id, u.roll_no, u.name;

CREATE VIEW v_meal_demand AS
SELECT meal_date, meal_type, COUNT(*) AS registered
FROM meal_registrations WHERE status = 'Registered'
GROUP BY meal_date, meal_type;

-- ---------------------------------------------------------------- Business rules in the database
DELIMITER //

-- Room capacity guard: reject an allocation that would over-fill a room or use a room under maintenance.
CREATE TRIGGER trg_allocation_capacity BEFORE INSERT ON allocations
FOR EACH ROW
BEGIN
  DECLARE v_capacity INT;
  DECLARE v_maint BOOLEAN;
  DECLARE v_occupied INT;

  SELECT capacity, under_maintenance INTO v_capacity, v_maint FROM rooms WHERE room_no = NEW.room_no FOR UPDATE;
  SELECT COUNT(*) INTO v_occupied FROM allocations WHERE room_no = NEW.room_no AND status = 'Active';

  IF v_maint THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Room is under maintenance';
  ELSEIF NEW.status = 'Active' AND v_occupied >= v_capacity THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Room is full';
  END IF;
END//

-- Attendance cannot be recorded for a future date.
CREATE TRIGGER trg_attendance_no_future BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
  IF NEW.att_date > CURDATE() THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Attendance cannot be marked for a future date';
  END IF;
END//

-- Fee payment as one atomic transaction: create the receipt and mark the fee paid, or change nothing.
CREATE PROCEDURE sp_record_payment(IN p_fee_id VARCHAR(30), IN p_method VARCHAR(20), IN p_admin VARCHAR(20), OUT p_receipt VARCHAR(40))
BEGIN
  DECLARE v_student VARCHAR(20);
  DECLARE v_amount DECIMAL(10,2);
  DECLARE v_status VARCHAR(10);

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  SELECT student_id, amount, status INTO v_student, v_amount, v_status FROM fees WHERE id = p_fee_id FOR UPDATE;

  IF v_status IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Fee record not found';
  ELSEIF v_status = 'paid' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Fee is already paid';
  END IF;

  SET p_receipt = CONCAT('RCP-', DATE_FORMAT(NOW(), '%Y%m'), '-', LPAD(FLOOR(RAND() * 100000), 5, '0'));
  INSERT INTO payments (id, fee_id, student_id, amount, method, payment_date, receipt_no, recorded_by)
  VALUES (CONCAT('pay-', UUID_SHORT()), p_fee_id, v_student, v_amount, p_method, NOW(), p_receipt, p_admin);
  UPDATE fees SET status = 'paid', payment_date = NOW(), receipt_no = p_receipt WHERE id = p_fee_id;
  COMMIT;
END//

DELIMITER ;

-- ---------------------------------------------------------------- Sample report queries
-- Students without a room:
--   SELECT u.roll_no, u.name FROM users u LEFT JOIN allocations a ON a.student_id = u.id AND a.status = 'Active'
--   WHERE u.role = 'student' AND u.status = 'active' AND a.id IS NULL;
-- Food requirement for tomorrow:
--   SELECT meal_type, registered FROM v_meal_demand WHERE meal_date = CURDATE() + INTERVAL 1 DAY;
-- Students with attendance below 75%:
--   SELECT * FROM v_attendance_summary WHERE attendance_pct < 75;
