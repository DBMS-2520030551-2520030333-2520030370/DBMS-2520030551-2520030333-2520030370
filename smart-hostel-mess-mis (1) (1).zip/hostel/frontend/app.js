(function () {
  const root = document.getElementById("app-root");
  const toastRegion = document.getElementById("toast-region");

  const credentials = {
    admin: ["admin@hostel.test", "admin123"],
    mess: ["mess@hostel.test", "mess123"],
    student: ["aarav@student.test", "student123"]
  };

  const allViews = {
    dashboard: ["Dashboard", "home", "Live summary across all hostel and mess services."],
    students: ["Students", "users", "Student registration, profiles, and guardian details."],
    rooms: ["Rooms", "bed", "Room availability, occupancy, and allocation."],
    fees: ["Fees", "credit", "Hostel fee ledger, pending dues, and receipts."],
    attendance: ["Attendance", "clipboard", "Daily attendance and leave requests."],
    mess: ["Mess", "utensils", "Weekly menu, meal registration, and demand."],
    complaints: ["Complaints", "alert", "Issue tracking from submission to resolution."],
    notices: ["Notices", "bell", "Announcements and personal notifications."],
    architecture: ["Architecture", "database", "Services, database ownership, and access control."]
  };

  const menus = {
    admin: ["dashboard", "students", "rooms", "fees", "attendance", "mess", "complaints", "notices", "architecture"],
    mess: ["dashboard", "mess", "complaints", "notices"],
    student: ["dashboard", "fees", "attendance", "mess", "complaints", "notices"]
  };

  const mealTypes = ["Breakfast", "Lunch", "Snacks", "Dinner"];
  const weekDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const statusColors = { good: ["paid", "approved", "resolved", "available", "active", "present", "registered", "served"], warn: ["pending", "assigned", "late", "maintenance", "on leave"], bad: ["overdue", "rejected", "absent", "full", "cancelled", "vacated", "unavailable"], info: ["in progress", "ok"] };

  const emptyData = () => ({
    students: [], rooms: [], allocations: [], fees: [], payments: [], attendance: [], leaves: [],
    menu: [], registrations: [], mealAttendance: [], complaints: [], notices: [], notifications: [],
    demand: {}, health: null, overview: null
  });

  const state = {
    token: localStorage.getItem("hostel-token") || "",
    user: JSON.parse(localStorage.getItem("hostel-user") || "null"),
    view: "dashboard",
    loading: false,
    query: "",
    attDate: new Date().toISOString().slice(0, 10),
    attDraft: {},
    data: emptyData()
  };

  const iconPaths = {
    home: '<path d="m3 10.8 9-7.2 9 7.2"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.8"/><path d="M16 3.2a4 4 0 0 1 0 7.6"/>',
    credit: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/><path d="M6 15h4"/>',
    alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    bed: '<path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M2 16h20"/><path d="M6 10V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v4"/>',
    utensils: '<path d="M3 2v7c0 1.1.9 2 2 2h2a2 2 0 0 0 2-2V2"/><path d="M6 2v20"/><path d="M19 2c-2.2 1.3-3 3.6-3 6.5V14h3v8"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
    refresh: '<path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M3 3v6h6"/><path d="M21 21v-6h-6"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>'
  };

  const icon = (name) => `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.home}</svg>`;
  const esc = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  const money = (value) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value || 0));
  const today = () => new Date().toISOString().slice(0, 10);
  const addDays = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  const dayName = (date) => new Date(`${date}T00:00:00Z`).toLocaleDateString("en-US", { weekday: "long", timeZone: "UTC" });
  const dateOnly = (value) => value ? new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(value)) : "Not set";
  const dateTime = (value) => value ? new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value)) : "Not recorded";
  const role = () => (state.user ? state.user.role : "");
  const isStaff = () => role() === "admin" || role() === "mess";

  function statusPill(value) {
    const key = String(value || "").toLowerCase();
    const tone = Object.keys(statusColors).find((name) => statusColors[name].includes(key)) || "neutral";
    return `<span class="status ${tone}">${esc(value || "Unknown")}</span>`;
  }

  function toast(message) {
    const item = document.createElement("div");
    item.className = "toast";
    item.textContent = message;
    toastRegion.appendChild(item);
    setTimeout(() => item.remove(), 3500);
  }

  async function api(endpoint, options = {}) {
    const headers = {
      Accept: "application/json",
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.auth === false || !state.token ? {} : { Authorization: `Bearer ${state.token}` })
    };
    const response = await fetch(endpoint, { method: options.method || "GET", headers, body: options.body ? JSON.stringify(options.body) : undefined });
    const payload = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error((payload && payload.error) || `Request failed with status ${response.status}`);
    }

    return payload;
  }

  const formData = (form) => Object.fromEntries(new FormData(form).entries());
  const options = (list, value, label, selected) => list.map((item) => `<option value="${esc(value(item))}" ${value(item) === selected ? "selected" : ""}>${esc(label(item))}</option>`).join("");
  const studentName = (id) => { const s = state.data.students.find((item) => item.id === id); return s ? `${s.name} (${s.rollNo})` : id; };
  const activeStudents = () => state.data.students.filter((s) => s.role === "student" && s.status === "active");
  const table = (inner) => `<div class="table-scroll"><table class="data-table">${inner}</table></div>`;
  const empty = (message) => `<div class="empty-state">${esc(message)}</div>`;

  function kpi(label, value, iconName, tone) {
    return `<article class="kpi"><div class="kpi-icon" style="${tone ? `background:${tone[0]};color:${tone[1]}` : ""}">${icon(iconName)}</div><div><strong>${esc(value)}</strong><span>${esc(label)}</span></div></article>`;
  }

  const AMBER = ["#fff1d6", "var(--amber)"];
  const CORAL = ["#ffe2dc", "var(--coral)"];
  const VIOLET = ["#e5e7ff", "var(--violet)"];
  const GREEN = ["#e8f4dd", "var(--green)"];

  async function loadData() {
    state.loading = true;
    render();

    const r = role();
    const plan = {
      students: ["/api/students", true],
      rooms: ["/api/rooms", r === "admin"],
      allocations: ["/api/allocations", r !== "mess"],
      fees: ["/api/fees", r !== "mess"],
      payments: ["/api/payments", r !== "mess"],
      attendance: ["/api/attendance", r !== "mess"],
      leaves: ["/api/leaves", r !== "mess"],
      menu: ["/api/menu", true],
      registrations: ["/api/registrations", true],
      mealAttendance: ["/api/meal-attendance", isStaff()],
      complaints: ["/api/complaints", true],
      notices: ["/api/notices", true],
      notifications: ["/api/notifications", r !== "mess"],
      overview: ["/api/overview", isStaff()],
      health: ["/api/service-status", r === "admin"],
      demandToday: [`/api/demand?date=${today()}`, isStaff()],
      demandTomorrow: [`/api/demand?date=${addDays(1)}`, isStaff()]
    };

    const keys = Object.keys(plan).filter((key) => plan[key][1]);
    const results = await Promise.allSettled(keys.map((key) => api(plan[key][0])));
    const data = emptyData();
    const failures = [];

    results.forEach((result, index) => {
      if (result.status === "fulfilled") {
        data[keys[index]] = result.value;
      } else {
        failures.push(result.reason.message);
      }
    });

    state.data = data;
    state.loading = false;

    if (failures.some((message) => message.includes("Authentication"))) {
      logout(false);
      return;
    }

    if (failures.length) {
      toast(`Some data could not be loaded: ${failures[0]}`);
    }

    render();
  }

  function renderLogin() {
    root.innerHTML = `
      <main class="login-screen">
        <section class="login-visual">
          <div class="brand-lockup">
            <div class="brand-mark">${icon("bed")}</div>
            <h1>Smart Hostel &amp; Mess Console</h1>
            <p>Student records, room allocation, fees, attendance, mess planning, complaints, and notices in one integrated administration system.</p>
          </div>
          <div class="system-map" aria-label="Service map">
            <div class="map-row"><div class="map-node"><strong>Gateway</strong><span>Port 4000</span></div><div class="map-node"><strong>Auth + RBAC</strong><span>Signed token</span></div><div class="map-node"><strong>Frontend</strong><span>Web dashboard</span></div></div>
            <div class="map-row"><div class="map-node"><strong>Students &amp; Rooms</strong><span>DB-1</span></div><div class="map-node"><strong>Fees</strong><span>DB-2</span></div><div class="map-node"><strong>Complaints</strong><span>DB-3</span></div></div>
            <div class="map-row"><div class="map-node"><strong>Attendance</strong><span>DB-4</span></div><div class="map-node"><strong>Mess</strong><span>DB-5</span></div><div class="map-node"><strong>Notices</strong><span>DB-6</span></div></div>
          </div>
        </section>
        <section class="login-panel">
          <form class="auth-box" id="login-form">
            <h2>Sign in</h2>
            <p>Use a demo role or enter seeded credentials.</p>
            <div class="preset-grid">
              <button type="button" class="preset-btn" data-login-preset="admin">${icon("database")} Admin</button>
              <button type="button" class="preset-btn" data-login-preset="mess">${icon("utensils")} Mess Staff</button>
              <button type="button" class="preset-btn" data-login-preset="student">${icon("users")} Student</button>
            </div>
            <div class="form-grid">
              <div class="field full"><label for="email">Email</label><input id="email" name="email" autocomplete="username" value="admin@hostel.test" required></div>
              <div class="field full"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" value="admin123" required></div>
            </div>
            <p class="auth-error" id="auth-error"></p>
            <button class="primary-btn" type="submit">${icon("check")} Sign in</button>
          </form>
        </section>
      </main>`;
  }

  function renderShell() {
    const menu = menus[role()] || menus.student;
    if (!menu.includes(state.view)) {
      state.view = "dashboard";
    }
    const current = allViews[state.view];

    root.innerHTML = `
      <div class="app-shell">
        <aside class="sidebar">
          <div class="sidebar-brand"><div class="brand-mark">${icon("bed")}</div><div><span>Smart Hostel</span><strong>Mess Console</strong></div></div>
          <nav class="nav" aria-label="Primary">
            ${menu.map((id) => `<button class="nav-btn ${state.view === id ? "active" : ""}" data-nav="${id}" title="${esc(allViews[id][0])}">${icon(allViews[id][1])} <span>${esc(allViews[id][0])}</span></button>`).join("")}
          </nav>
          <div class="sidebar-footer">
            <div class="user-chip"><strong>${esc(state.user.name)}</strong><span>${esc(state.user.role)}${state.user.roomNo ? ` / Room ${esc(state.user.roomNo)}` : ""}</span></div>
            <button class="ghost-btn" data-logout>${icon("logout")} Sign out</button>
          </div>
        </aside>
        <main class="main-area">
          <header class="topbar">
            <div class="view-title"><h2>${esc(current[0])}</h2><p>${esc(current[2])}</p></div>
            <div class="topbar-actions">
              <button class="icon-btn" title="Refresh data" data-refresh>${icon("refresh")}</button>
              <button class="icon-btn mobile-nav" title="Sign out" data-logout>${icon("logout")}</button>
            </div>
          </header>
          <div class="content">${state.loading ? `<section class="band"><div class="empty-state">Loading live data from the gateway and services...</div></section>` : currentView()}</div>
        </main>
      </div>`;
  }

  function currentView() {
    const map = { dashboard: dashboardView, students: studentsView, rooms: roomsView, fees: feesView, attendance: attendanceView, mess: messView, complaints: complaintsView, notices: noticesView, architecture: architectureView };
    return map[state.view]();
  }

  const meters = (rows, total) => `<div class="meter-list">${rows.map(([label, count]) => `<div class="meter-row"><span class="small">${esc(label)}</span><div class="meter"><span style="width:${Math.max(3, Math.round((count / Math.max(1, total)) * 100))}%"></span></div><strong>${count}</strong></div>`).join("")}</div>`;

  function noticeCard(notice) {
    return `<article class="item-card"><div class="item-head"><strong>${esc(notice.title)}</strong>${statusPill(notice.priority)}</div><span class="small muted">${esc(notice.category)} - ${dateOnly(notice.createdDate)}${notice.expiresOn ? ` - until ${dateOnly(notice.expiresOn)}` : ""}</span><p class="small" style="margin:0">${esc(notice.description)}</p></article>`;
  }

  function menuFor(date) {
    const day = dayName(date);
    return mealTypes.map((meal) => [meal, state.data.menu.find((item) => item.day === day && item.mealType === meal)]);
  }

  const menuList = (date) => `<div class="list">${menuFor(date).map(([meal, entry]) => `<div class="item-card"><div class="item-head"><strong>${meal}</strong>${entry ? statusPill(entry.isVeg ? "Veg" : "Non-veg") : ""}</div><span class="small">${entry ? esc(entry.items) : "Not scheduled"}</span></div>`).join("")}</div>`;

  function demandPanel(demand, title) {
    const meals = (demand && demand.meals) || {};
    const total = Math.max(1, ...Object.values(meals).map((m) => m.registered));
    return `<div class="panel"><div class="panel-title"><h3>${esc(title)}</h3><span>${esc(demand && demand.day ? `${demand.day}, ${dateOnly(demand.date)}` : "")}</span></div>${meters(mealTypes.map((meal) => [`${meal} (served ${meals[meal] ? meals[meal].attended : 0})`, meals[meal] ? meals[meal].registered : 0]), total)}</div>`;
  }

  function dashboardView() {
    const d = state.data;
    const s = d.overview ? d.overview.summary : {};
    const openComplaints = d.complaints.filter((c) => c.status !== "Resolved");
    const flow = ["Pending", "Assigned", "In Progress", "Resolved"].map((status) => [status, d.complaints.filter((c) => c.status === status).length]);
    const notices = `<div class="panel"><div class="panel-title"><h3>Latest Notices</h3><span>${d.notices.length} published</span></div><div class="list">${d.notices.slice(0, 3).map(noticeCard).join("") || empty("No notices")}</div></div>`;
    const complaintPanel = `<div class="panel"><div class="panel-title"><h3>Complaint Flow</h3><span>${openComplaints.length} open</span></div>${meters(flow, d.complaints.length)}</div>`;

    if (role() === "student") {
      const me = d.students[0] || state.user;
      const unpaid = d.fees.filter((f) => f.status !== "paid");
      const marked = d.attendance.filter((a) => a.status !== "On Leave");
      const percent = marked.length ? Math.round((marked.filter((a) => a.status !== "Absent").length / marked.length) * 100) : 100;
      const mine = d.registrations.filter((r) => r.status === "Registered" && r.date >= today()).slice(0, 5);
      return `
        <section class="kpi-grid">
          ${kpi("My room", me.roomNo || "Not allocated", "bed")}
          ${kpi("Pending fees", money(unpaid.reduce((sum, f) => sum + f.amount, 0)), "credit", AMBER)}
          ${kpi("Attendance", `${percent}%`, "clipboard", GREEN)}
          ${kpi("Open complaints", openComplaints.length, "alert", CORAL)}
        </section>
        <section class="grid-2">
          <div class="panel"><div class="panel-title"><h3>Today's Menu</h3><span>${dayName(today())}</span></div>${menuList(today())}</div>
          <div class="panel"><div class="panel-title"><h3>My Upcoming Meals</h3><span>${mine.length} registered</span></div>${mine.length ? table(`<thead><tr><th>Date</th><th>Meal</th></tr></thead><tbody>${mine.map((r) => `<tr><td>${dateOnly(r.date)}</td><td>${esc(r.mealType)}</td></tr>`).join("")}</tbody>`) : empty("No upcoming meal registrations")}</div>
        </section>
        <section class="grid-2">${notices}<div class="panel"><div class="panel-title"><h3>Notifications</h3><span>${d.notifications.filter((n) => !n.read).length} unread</span></div><div class="list">${d.notifications.slice(0, 4).map(notificationCard).join("") || empty("No notifications")}</div></div></section>`;
    }

    const kpis = role() === "admin"
      ? `${kpi("Students", s.students || 0, "users")}${kpi("Bed occupancy", `${s.occupancyRate || 0}% (${s.occupiedBeds || 0}/${s.totalBeds || 0})`, "bed", VIOLET)}${kpi("Pending fees", money(s.pendingFeeAmount || 0), "credit", AMBER)}${kpi("Open complaints", s.openComplaints || 0, "alert", CORAL)}${kpi("Present today", s.presentToday || 0, "clipboard")}${kpi("Meals registered today", s.mealsRegisteredToday || 0, "utensils", GREEN)}`
      : `${kpi("Meals registered today", s.mealsRegisteredToday || 0, "utensils", GREEN)}${kpi("Meals served today", d.overview?.stats?.mess?.servedToday || 0, "check")}${kpi("Menu slots", d.overview?.stats?.mess?.menuItems || 0, "clipboard", VIOLET)}${kpi("Open complaints", openComplaints.length, "alert", CORAL)}`;

    const health = role() === "admin" ? `
      <section class="band"><div class="panel-title"><h3>Service Health</h3><span>${d.overview ? `Updated ${dateTime(d.overview.generatedAt)}` : ""}</span></div>
        <div class="service-grid">${(d.health?.services || []).map((sv) => `<div class="service-tile"><strong>${esc(sv.name)}</strong>${statusPill(sv.ok ? "ok" : "unavailable")}<span>${esc(sv.url)}</span></div>`).join("")}</div></section>` : "";

    const dues = d.fees.filter((f) => f.status !== "paid").slice(0, 5);
    const duesPanel = role() === "admin" ? `<div class="panel"><div class="panel-title"><h3>Pending Dues</h3><span>${s.studentsWithDues || 0} students</span></div>${dues.length ? table(`<thead><tr><th>Student</th><th>Fee</th><th>Amount</th><th>Status</th></tr></thead><tbody>${dues.map((f) => `<tr><td>${esc(studentName(f.studentId))}</td><td>${esc(f.feeType)}</td><td>${money(f.amount)}</td><td>${statusPill(f.status)}</td></tr>`).join("")}</tbody>`) : empty("No pending fees")}</div>` : `<div class="panel"><div class="panel-title"><h3>Today's Menu</h3><span>${dayName(today())}</span></div>${menuList(today())}</div>`;

    return `
      <section class="kpi-grid">${kpis}</section>${health}
      <section class="grid-2">${complaintPanel}${duesPanel}</section>
      <section class="grid-2">${demandPanel(d.demandToday, "Meal Demand - Today")}${demandPanel(d.demandTomorrow, "Meal Demand - Tomorrow")}</section>
      <section class="grid-2">${notices}${role() === "admin" ? `<div class="panel"><div class="panel-title"><h3>Leave Requests</h3><span>${s.pendingLeaves || 0} pending</span></div>${leaveTable(d.leaves.filter((l) => l.status === "Pending").slice(0, 4), true)}</div>` : ""}</section>`;
  }

  function notificationCard(n) {
    return `<article class="item-card"><div class="item-head"><strong>${esc(n.title)}</strong>${n.read ? statusPill("Read") : `<button class="ghost-btn" data-read="${esc(n.id)}">${icon("check")} Mark read</button>`}</div><span class="small">${esc(n.message)}</span><span class="small muted">${dateTime(n.createdAt)}</span></article>`;
  }

  function studentsView() {
    const q = state.query.toLowerCase();
    const list = state.data.students.filter((s) => !q || `${s.name} ${s.rollNo} ${s.email} ${s.course}`.toLowerCase().includes(q));
    return `
      <section class="grid-2">
        <form class="panel" id="student-form">
          <div class="panel-title"><h3>Register Student</h3><span>${state.data.students.filter((s) => s.status === "pending").length} pending</span></div>
          <div class="form-grid">
            <div class="field"><label>Full name</label><input name="name" required></div>
            <div class="field"><label>Roll number</label><input name="rollNo" required></div>
            <div class="field"><label>Phone (10 digits)</label><input name="phone" pattern="\\d{10}" required></div>
            <div class="field"><label>Email</label><input name="email" type="email" required></div>
            <div class="field"><label>Course</label><input name="course" value="B.Tech CSE" required></div>
            <div class="field"><label>Year</label><input name="year" type="number" min="1" max="6" value="1"></div>
            <div class="field"><label>Guardian name</label><input name="guardianName"></div>
            <div class="field"><label>Guardian phone</label><input name="guardianPhone"></div>
            <div class="field"><label>Status</label><select name="status"><option>active</option><option>pending</option></select></div>
          </div>
          <div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Register</button></div>
        </form>
        <div class="panel"><div class="panel-title"><h3>Overview</h3><span>${state.data.students.length} students</span></div>
          <div class="kpi-grid" style="grid-template-columns:repeat(2,minmax(120px,1fr))">
            ${kpi("Active", state.data.students.filter((s) => s.status === "active").length, "users")}
            ${kpi("Without room", state.data.students.filter((s) => s.status === "active" && !s.roomNo).length, "bed", AMBER)}
          </div>
          <p class="small muted">New students receive the default password <strong>student123</strong> (stored hashed).</p>
        </div>
      </section>
      <section class="panel">
        <div class="panel-title"><h3>Student Directory</h3><input id="student-search" placeholder="Search name, roll no, course" value="${esc(state.query)}" style="max-width:260px"></div>
        <div id="students-table">${studentsTable(list)}</div>
      </section>`;
  }

  function studentsTable(list) {
    return table(`<thead><tr><th>Roll no</th><th>Name</th><th>Course</th><th>Room</th><th>Guardian</th><th>Status</th><th>Action</th></tr></thead><tbody>${list.map((s) => `
      <tr><td>${esc(s.rollNo)}</td><td><strong>${esc(s.name)}</strong><br><span class="small muted">${esc(s.email)} / ${esc(s.phone)}</span></td><td>${esc(s.course)} (Y${s.year})</td>
      <td>${s.roomNo ? esc(s.roomNo) : '<span class="muted">-</span>'}</td><td>${esc(s.guardianName)}<br><span class="small muted">${esc(s.guardianPhone)}</span></td><td>${statusPill(s.status)}</td>
      <td>${s.status === "pending" ? `<button class="primary-btn" data-student-status="${esc(s.id)}" data-value="active">${icon("check")} Approve</button>` : s.status === "active" ? `<button class="ghost-btn" data-student-status="${esc(s.id)}" data-value="vacated">Mark vacated</button>` : ""}</td></tr>`).join("")}</tbody>`);
  }

  function roomsView() {
    const d = state.data;
    const unallocated = activeStudents().filter((s) => !s.roomNo);
    const open = d.rooms.filter((r) => r.status === "Available");
    const current = d.allocations.filter((a) => a.status === "Active");
    return `
      <section class="grid-2">
        <form class="panel" id="allocation-form">
          <div class="panel-title"><h3>Allocate Room</h3><span>${unallocated.length} students waiting</span></div>
          <div class="form-grid">
            <div class="field"><label>Student</label><select name="studentId" required>${options(unallocated, (s) => s.id, (s) => `${s.name} (${s.rollNo})`)}</select></div>
            <div class="field"><label>Room</label><select name="roomNo" required>${options(open, (r) => r.roomNo, (r) => `${r.roomNo} - ${r.vacant} vacant of ${r.capacity}`)}</select></div>
          </div>
          <div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit" ${unallocated.length && open.length ? "" : "disabled"}>${icon("check")} Allocate</button></div>
        </form>
        <form class="panel" id="room-form">
          <div class="panel-title"><h3>Add Room</h3><span>${d.rooms.length} rooms</span></div>
          <div class="form-grid">
            <div class="field"><label>Room no</label><input name="roomNo" placeholder="C-101" required></div>
            <div class="field"><label>Block</label><input name="block" value="A" required></div>
            <div class="field"><label>Floor</label><input name="floor" type="number" min="0" value="1" required></div>
            <div class="field"><label>Capacity</label><input name="capacity" type="number" min="1" max="6" value="2" required></div>
          </div>
          <div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Add room</button></div>
        </form>
      </section>
      <section class="panel"><div class="panel-title"><h3>Room Availability</h3><span>${d.rooms.reduce((sum, r) => sum + r.occupied, 0)} beds occupied</span></div>
        <div class="flat-grid">${d.rooms.map((r) => `<div class="flat-card"><div class="item-head"><strong>${esc(r.roomNo)}</strong>${statusPill(r.status)}</div><span class="small muted">Block ${esc(r.block)} - Floor ${r.floor} - ${esc(r.roomType)}</span><span>${r.occupied} / ${r.capacity} beds occupied</span><div class="meter"><span style="width:${Math.round((r.occupied / r.capacity) * 100)}%"></span></div><button class="ghost-btn" data-maint="${esc(r.roomNo)}" data-value="${r.status === "Maintenance" ? "false" : "true"}">${r.status === "Maintenance" ? "Reopen room" : "Mark maintenance"}</button></div>`).join("")}</div></section>
      <section class="panel"><div class="panel-title"><h3>Active Allocations</h3><span>${current.length}</span></div>
        ${current.length ? table(`<thead><tr><th>Student</th><th>Room</th><th>Since</th><th>Action</th></tr></thead><tbody>${current.map((a) => `<tr><td>${esc(studentName(a.studentId))}</td><td>${esc(a.roomNo)}</td><td>${dateOnly(a.allocatedOn)}</td><td><button class="ghost-btn" data-vacate="${esc(a.id)}">Vacate</button></td></tr>`).join("")}</tbody>`) : empty("No active allocations")}</section>`;
  }

  function feesView() {
    const d = state.data;
    const admin = role() === "admin";
    const unpaid = d.fees.filter((f) => f.status !== "paid");
    const form = admin ? `
      <section class="grid-2">
        <form class="panel" id="fee-form">
          <div class="panel-title"><h3>Raise Fee</h3><span>${unpaid.length} unpaid</span></div>
          <div class="form-grid">
            <div class="field"><label>Student</label><select name="studentId" required>${options(activeStudents(), (s) => s.id, (s) => `${s.name} (${s.rollNo})`)}</select></div>
            <div class="field"><label>Fee type</label><select name="feeType">${["Hostel Rent", "Mess Charges", "Security Deposit", "Electricity", "Fine", "Other"].map((t) => `<option>${t}</option>`).join("")}</select></div>
            <div class="field"><label>Amount</label><input name="amount" type="number" min="1" value="3600" required></div>
            <div class="field"><label>Term</label><input name="term" value="${today().slice(0, 7)}" required></div>
            <div class="field"><label>Due date</label><input name="dueDate" type="date" value="${addDays(15)}" required></div>
            <div class="field"><label>Notes</label><input name="notes"></div>
          </div>
          <div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Add fee</button></div>
        </form>
        <div class="panel"><div class="panel-title"><h3>Collection Snapshot</h3><span>${money(d.overview?.stats?.fee?.totalCollected || 0)} collected</span></div>
          <div class="kpi-grid" style="grid-template-columns:repeat(2,minmax(120px,1fr))">${kpi("Pending", money(d.overview?.stats?.fee?.pendingAmount || 0), "credit", AMBER)}${kpi("Overdue bills", d.overview?.stats?.fee?.overdueFees || 0, "alert", CORAL)}</div></div>
      </section>` : `<section class="kpi-grid">${kpi("Pending amount", money(unpaid.reduce((sum, f) => sum + f.amount, 0)), "credit", AMBER)}${kpi("Paid so far", money(d.payments.reduce((sum, p) => sum + p.amount, 0)), "check", GREEN)}</section>`;

    return `${form}
      <section class="panel"><div class="panel-title"><h3>Fee Ledger</h3><span>${d.fees.length} records</span></div>
        ${table(`<thead><tr>${admin ? "<th>Student</th>" : ""}<th>Fee</th><th>Term</th><th>Amount</th><th>Due</th><th>Status</th>${admin ? "<th>Action</th>" : "<th>Receipt</th>"}</tr></thead><tbody>${d.fees.map((f) => `
          <tr>${admin ? `<td>${esc(studentName(f.studentId))}</td>` : ""}<td>${esc(f.feeType)}</td><td>${esc(f.term)}</td><td>${money(f.amount)}</td><td>${dateOnly(f.dueDate)}</td><td>${statusPill(f.status)}</td>
          <td>${f.status === "paid" ? `<span class="muted small">${esc(f.receiptNo || "")}</span>` : admin ? `<div class="row-actions"><select id="method-${esc(f.id)}"><option>UPI</option><option>Cash</option><option>Card</option><option>Bank Transfer</option></select><button class="primary-btn" data-pay="${esc(f.id)}" data-student="${esc(f.studentId)}">${icon("credit")} Record</button></div>` : '<span class="muted small">Contact hostel office to pay</span>'}</td></tr>`).join("")}</tbody>`)}</section>
      <section class="panel"><div class="panel-title"><h3>Payment History</h3><span>${d.payments.length} receipts</span></div>
        ${d.payments.length ? table(`<thead><tr><th>Receipt</th>${admin ? "<th>Student</th>" : ""}<th>Fee</th><th>Amount</th><th>Method</th><th>Paid on</th></tr></thead><tbody>${d.payments.map((p) => `<tr><td><strong>${esc(p.receiptNo)}</strong></td>${admin ? `<td>${esc(p.studentName)}</td>` : ""}<td>${esc(p.feeType)} (${esc(p.term)})</td><td>${money(p.amount)}</td><td>${esc(p.method)}</td><td>${dateTime(p.paymentDate)}</td></tr>`).join("")}</tbody>`) : empty("No payments recorded")}</section>`;
  }

  function leaveTable(list, review) {
    if (!list.length) {
      return empty("No leave requests");
    }
    return table(`<thead><tr>${review ? "<th>Student</th>" : ""}<th>Dates</th><th>Reason</th><th>Status</th>${review ? "<th>Action</th>" : ""}</tr></thead><tbody>${list.map((l) => `
      <tr>${review ? `<td>${esc(studentName(l.studentId))}</td>` : ""}<td>${dateOnly(l.fromDate)} - ${dateOnly(l.toDate)}</td><td>${esc(l.reason)}${l.destination ? `<br><span class="small muted">${esc(l.destination)}</span>` : ""}</td><td>${statusPill(l.status)}</td>
      ${review ? `<td>${l.status === "Pending" ? `<div class="row-actions"><button class="primary-btn" data-leave="${esc(l.id)}" data-value="Approved">${icon("check")}</button><button class="danger-btn" data-leave="${esc(l.id)}" data-value="Rejected">${icon("x")}</button></div>` : ""}</td>` : ""}</tr>`).join("")}</tbody>`);
  }

  function attendanceView() {
    const d = state.data;
    if (role() === "student") {
      const counts = { Present: 0, Absent: 0, Late: 0, "On Leave": 0 };
      d.attendance.forEach((a) => { counts[a.status] += 1; });
      const considered = d.attendance.length - counts["On Leave"];
      const percent = considered ? Math.round(((counts.Present + counts.Late) / considered) * 100) : 100;
      return `
        <section class="kpi-grid">${kpi("Attendance", `${percent}%`, "clipboard", GREEN)}${kpi("Present", counts.Present, "check")}${kpi("Late", counts.Late, "alert", AMBER)}${kpi("Absent", counts.Absent, "x", CORAL)}</section>
        <section class="grid-2">
          <form class="panel" id="leave-form"><div class="panel-title"><h3>Request Leave</h3><span>Warden approval required</span></div>
            <div class="form-grid">
              <div class="field"><label>From</label><input name="fromDate" type="date" min="${today()}" value="${today()}" required></div>
              <div class="field"><label>To</label><input name="toDate" type="date" min="${today()}" value="${today()}" required></div>
              <div class="field"><label>Destination</label><input name="destination"></div>
              <div class="field"><label>Reason</label><input name="reason" required></div>
            </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Submit request</button></div></form>
          <div class="panel"><div class="panel-title"><h3>My Leave Requests</h3><span>${d.leaves.length}</span></div>${leaveTable(d.leaves, false)}</div>
        </section>
        <section class="panel"><div class="panel-title"><h3>Recent Attendance</h3><span>Last ${Math.min(14, d.attendance.length)} days</span></div>
          ${table(`<thead><tr><th>Date</th><th>Status</th><th>Remark</th></tr></thead><tbody>${d.attendance.slice(0, 14).map((a) => `<tr><td>${dateOnly(a.date)}</td><td>${statusPill(a.status)}</td><td>${esc(a.remark)}</td></tr>`).join("")}</tbody>`)}</section>`;
    }

    const residents = activeStudents().filter((s) => s.roomNo);
    const saved = Object.fromEntries(d.attendance.filter((a) => a.date === state.attDate).map((a) => [a.studentId, a.status]));
    const pct = (id) => {
      const rows = d.attendance.filter((a) => a.studentId === id && a.status !== "On Leave");
      return rows.length ? Math.round((rows.filter((a) => a.status !== "Absent").length / rows.length) * 100) : 100;
    };
    return `
      <section class="panel">
        <div class="panel-title"><h3>Mark Attendance</h3><div class="row-actions"><input type="date" id="att-date" value="${state.attDate}" max="${today()}"><button class="primary-btn" data-save-attendance>${icon("check")} Save ${residents.length} records</button></div></div>
        ${table(`<thead><tr><th>Student</th><th>Room</th><th>Status</th><th>Overall</th></tr></thead><tbody>${residents.map((s) => {
          const value = state.attDraft[s.id] || saved[s.id] || "Present";
          return `<tr><td>${esc(s.name)} <span class="small muted">${esc(s.rollNo)}</span></td><td>${esc(s.roomNo)}</td><td><select data-att="${esc(s.id)}">${["Present", "Absent", "Late", "On Leave"].map((o) => `<option ${o === value ? "selected" : ""}>${o}</option>`).join("")}</select> ${saved[s.id] ? "" : '<span class="small muted">not marked</span>'}</td><td>${pct(s.id)}%</td></tr>`;
        }).join("")}</tbody>`)}
      </section>
      <section class="panel"><div class="panel-title"><h3>Leave Requests</h3><span>${d.leaves.filter((l) => l.status === "Pending").length} pending</span></div>${leaveTable(d.leaves, true)}</section>`;
  }

  function messView() {
    const d = state.data;
    const student = role() === "student";
    const weekly = table(`<thead><tr><th>Day</th>${mealTypes.map((m) => `<th>${m}</th>`).join("")}</tr></thead><tbody>${weekDays.map((day) => `<tr><td><strong>${day}</strong></td>${mealTypes.map((m) => { const e = d.menu.find((x) => x.day === day && x.mealType === m); return `<td class="small">${e ? esc(e.items) : "-"}</td>`; }).join("")}</tr>`).join("")}</tbody>`);
    const menuPanel = `<section class="panel"><div class="panel-title"><h3>Weekly Menu</h3><span>${d.menu.length} entries</span></div>${weekly}</section>`;

    if (student) {
      const mine = d.registrations.filter((r) => r.status === "Registered" && r.date >= today());
      return `
        <section class="grid-2">
          <form class="panel" id="register-form"><div class="panel-title"><h3>Register for a Meal</h3><span>Helps the mess plan food</span></div>
            <div class="form-grid">
              <div class="field"><label>Date</label><input name="date" type="date" min="${today()}" value="${addDays(1)}" required></div>
              <div class="field"><label>Meal</label><select name="mealType">${mealTypes.map((m) => `<option>${m}</option>`).join("")}</select></div>
            </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Register</button></div></form>
          <div class="panel"><div class="panel-title"><h3>My Registrations</h3><span>${mine.length} upcoming</span></div>
            ${mine.length ? table(`<thead><tr><th>Date</th><th>Meal</th><th></th></tr></thead><tbody>${mine.map((r) => `<tr><td>${dateOnly(r.date)}</td><td>${esc(r.mealType)}</td><td><button class="ghost-btn" data-cancel-reg="${esc(r.id)}">Cancel</button></td></tr>`).join("")}</tbody>`) : empty("No upcoming registrations")}</div>
        </section>${menuPanel}`;
    }

    const served = d.mealAttendance.filter((m) => m.date === today());
    return `
      <section class="grid-2">
        <form class="panel" id="menu-form"><div class="panel-title"><h3>Set Menu</h3><span>Creates or updates a slot</span></div>
          <div class="form-grid">
            <div class="field"><label>Day</label><select name="day">${weekDays.map((x) => `<option>${x}</option>`).join("")}</select></div>
            <div class="field"><label>Meal</label><select name="mealType">${mealTypes.map((m) => `<option>${m}</option>`).join("")}</select></div>
            <div class="field full"><label>Items</label><input name="items" required></div>
            <div class="field"><label>Type</label><select name="isVeg"><option value="true">Veg</option><option value="false">Non-veg</option></select></div>
          </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("check")} Save menu</button></div></form>
        <form class="panel" id="served-form"><div class="panel-title"><h3>Record Meal Served</h3><span>${served.length} served today</span></div>
          <div class="form-grid">
            <div class="field"><label>Student</label><select name="studentId" required>${options(activeStudents().filter((s) => s.roomNo), (s) => s.id, (s) => `${s.name} (${s.rollNo})`)}</select></div>
            <div class="field"><label>Meal</label><select name="mealType">${mealTypes.map((m) => `<option>${m}</option>`).join("")}</select></div>
          </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("utensils")} Record</button></div></form>
      </section>
      <section class="grid-2">${demandPanel(d.demandToday, "Meal Demand - Today")}${demandPanel(d.demandTomorrow, "Meal Demand - Tomorrow")}</section>
      ${menuPanel}
      <section class="panel"><div class="panel-title"><h3>Served Today</h3><span>${served.length}</span></div>
        ${served.length ? table(`<thead><tr><th>Student</th><th>Meal</th><th>Registered</th><th>Time</th></tr></thead><tbody>${served.map((m) => `<tr><td>${esc(studentName(m.studentId))}</td><td>${esc(m.mealType)}</td><td>${statusPill(m.registered ? "Registered" : "Walk-in")}</td><td>${dateTime(m.servedAt)}</td></tr>`).join("")}</tbody>`) : empty("No meals recorded yet today")}</section>`;
  }

  function complaintsView() {
    const d = state.data;
    const next = { Pending: "Assigned", Assigned: "In Progress", "In Progress": "Resolved" };
    const student = role() === "student";
    return `
      <section class="grid-2">
        ${student || role() === "admin" ? `<form class="panel" id="complaint-form"><div class="panel-title"><h3>${student ? "Submit Complaint" : "Log Complaint"}</h3><span>${d.complaints.filter((c) => c.status !== "Resolved").length} open</span></div>
          <div class="form-grid">
            ${student ? "" : `<div class="field full"><label>Student</label><select name="studentId" required>${options(activeStudents(), (s) => s.id, (s) => `${s.name} (${s.rollNo})`)}</select></div>`}
            <div class="field"><label>Category</label><select name="category">${["Room", "Mess", "Water", "Electricity", "Cleaning", "Internet", "Security", "Other"].map((c) => `<option>${c}</option>`).join("")}</select></div>
            <div class="field"><label>Priority</label><select name="priority"><option>Low</option><option selected>Medium</option><option>High</option></select></div>
            <div class="field full"><label>Description</label><textarea name="description" rows="3" required></textarea></div>
          </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Submit</button></div></form>` : ""}
        <div class="panel"><div class="panel-title"><h3>Complaint Flow</h3><span>${d.complaints.length} total</span></div>${meters(["Pending", "Assigned", "In Progress", "Resolved"].map((s) => [s, d.complaints.filter((c) => c.status === s).length]), d.complaints.length)}</div>
      </section>
      <section class="panel"><div class="panel-title"><h3>${student ? "My Complaints" : "All Complaints"}</h3><span>${d.complaints.length}</span></div>
        <div class="list">${d.complaints.map((c) => `<article class="item-card"><div class="item-head"><strong>${esc(c.category)}${student ? "" : ` - ${esc(studentName(c.studentId))}`}</strong><div class="row-actions">${statusPill(c.priority)}${statusPill(c.status)}</div></div>
          <p class="small" style="margin:0">${esc(c.description)}</p><span class="small muted">Raised ${dateTime(c.createdDate)}${c.assignedTo ? ` - Assigned to ${esc(c.assignedTo)}` : ""}</span>
          <div class="timeline">${c.activity.map((a) => `<span>${dateTime(a.at)} - ${esc(a.message)}</span>`).join("")}</div>
          ${!student && next[c.status] ? `<div class="row-actions"><button class="primary-btn" data-complaint="${esc(c.id)}" data-next="${next[c.status]}" data-category="${esc(c.category)}">Move to ${next[c.status]}</button></div>` : ""}</article>`).join("") || empty("No complaints")}</div></section>`;
  }

  function noticesView() {
    const d = state.data;
    return `
      ${role() === "admin" ? `<section class="panel"><form id="notice-form"><div class="panel-title"><h3>Publish Notice</h3><span>${d.notices.length} published</span></div>
        <div class="form-grid">
          <div class="field"><label>Title</label><input name="title" required></div>
          <div class="field"><label>Category</label><select name="category"><option>Hostel</option><option>Mess</option><option>Fees</option><option>Maintenance</option><option>Events</option></select></div>
          <div class="field"><label>Priority</label><select name="priority"><option>Low</option><option selected>Medium</option><option>High</option></select></div>
          <div class="field"><label>Expires on</label><input name="expiresOn" type="date" value="${addDays(14)}"></div>
          <div class="field full"><label>Description</label><textarea name="description" rows="3" required></textarea></div>
        </div><div class="row-actions" style="margin-top:14px"><button class="primary-btn" type="submit">${icon("plus")} Publish</button></div></form></section>` : ""}
      <section class="grid-2">
        <div class="panel"><div class="panel-title"><h3>Notice Board</h3><span>${d.notices.length}</span></div><div class="list">${d.notices.map(noticeCard).join("") || empty("No notices")}</div></div>
        ${role() !== "mess" ? `<div class="panel"><div class="panel-title"><h3>Notifications</h3><span>${d.notifications.filter((n) => !n.read).length} unread</span></div><div class="list">${d.notifications.map(notificationCard).join("") || empty("No notifications")}</div></div>` : ""}
      </section>`;
  }

  function architectureView() {
    const node = (title, sub) => `<div class="topology-node"><strong>${title}</strong><span>${sub}</span></div>`;
    return `
      <section class="architecture-grid">
        <div class="panel"><div class="panel-title"><h3>Service Topology</h3><span>6 services + gateway</span></div>
          <div class="topology"><div class="topology-row"><div class="topology-node gateway"><strong>API Gateway :4000</strong><span>Auth, RBAC, routing, overview</span></div></div>
            <div class="topology-row">${node("Student Service :4101", "students, rooms, allocations")}${node("Fee Service :4102", "fees, payments, receipts")}${node("Complaint Service :4103", "complaints")}</div>
            <div class="topology-row">${node("Attendance Service :4104", "attendance, leaves")}${node("Mess Service :4105", "menu, registrations, demand")}${node("Notification Service :4106", "notices, notifications")}</div></div></div>
        <div class="panel"><div class="panel-title"><h3>Design Concepts</h3><span>DBMS and software engineering</span></div>
          <div class="concept-list"><span>Database per service</span><span>Role-based access control</span><span>Hashed passwords (scrypt)</span><span>Room capacity rules</span><span>Unique attendance per day</span><span>Transactional fee payment</span><span>Duplicate meal-registration guard</span><span>Fault isolation per service</span><span>Validation at UI and server</span><span>Aggregated dashboard API</span></div>
          <p class="small muted">The relational MySQL schema for the same design is in <strong>docs/database-schema.sql</strong>.</p></div>
      </section>
      <section class="panel"><div class="panel-title"><h3>Access Matrix</h3><span>Enforced by the gateway</span></div>
        ${table(`<thead><tr><th>Area</th><th>Admin</th><th>Mess staff</th><th>Student</th></tr></thead><tbody>
          <tr><td>Students and rooms</td><td>Full</td><td>Read students</td><td>Own profile</td></tr>
          <tr><td>Fees and payments</td><td>Full</td><td>None</td><td>Own, read-only</td></tr>
          <tr><td>Attendance and leave</td><td>Full</td><td>None</td><td>Own; request leave</td></tr>
          <tr><td>Mess menu and meals</td><td>Full</td><td>Full</td><td>View menu; own registrations</td></tr>
          <tr><td>Complaints</td><td>Full</td><td>Review and update</td><td>Submit and view own</td></tr>
          <tr><td>Notices</td><td>Publish</td><td>Read</td><td>Read</td></tr></tbody>`)}</section>`;
  }

  async function login(email, password) {
    const result = await api("/api/auth/login", { method: "POST", auth: false, body: { email, password } });
    state.token = result.token;
    state.user = result.user;
    state.view = "dashboard";
    localStorage.setItem("hostel-token", result.token);
    localStorage.setItem("hostel-user", JSON.stringify(result.user));
    await loadData();
    toast(`Signed in as ${result.user.role}`);
  }

  function logout(showToast = true) {
    state.token = "";
    state.user = null;
    state.data = emptyData();
    localStorage.removeItem("hostel-token");
    localStorage.removeItem("hostel-user");
    render();
    if (showToast) {
      toast("Signed out");
    }
  }

  async function mutate(endpoint, opts, message) {
    try {
      await api(endpoint, opts);
      toast(message);
      await loadData();
      return true;
    } catch (error) {
      toast(error.message);
      return false;
    }
  }

  const assignee = { Mess: "Mess Committee", Internet: "IT Support", Security: "Warden Office", Other: "Warden Office" };

  async function submitForm(event) {
    const form = event.target;
    const id = form.id;

    if (!id) {
      return;
    }

    event.preventDefault();
    const body = formData(form);

    try {
      if (id === "login-form") {
        const errorNode = document.getElementById("auth-error");
        errorNode.textContent = "";
        await login(body.email, body.password).catch((error) => { errorNode.textContent = error.message; });
        return;
      }

      if (id === "menu-form") {
        const existing = state.data.menu.find((m) => m.day === body.day && m.mealType === body.mealType);
        const ok = existing
          ? await mutate(`/api/menu/${existing.id}`, { method: "PATCH", body: { items: body.items, isVeg: body.isVeg } }, "Menu updated")
          : await mutate("/api/menu", { method: "POST", body }, "Menu added");
        if (ok) form.reset();
        return;
      }

      const actions = {
        "student-form": ["/api/students", "Student registered"],
        "room-form": ["/api/rooms", "Room added"],
        "allocation-form": ["/api/allocations", "Room allocated"],
        "fee-form": ["/api/fees", "Fee raised"],
        "leave-form": ["/api/leaves", "Leave request submitted"],
        "register-form": ["/api/registrations", "Meal registered"],
        "served-form": ["/api/meal-attendance", "Meal recorded"],
        "complaint-form": ["/api/complaints", "Complaint submitted"],
        "notice-form": ["/api/notices", "Notice published"]
      };

      if (!actions[id]) {
        return;
      }

      if (id === "notice-form") body.adminId = state.user.id;
      if (id === "served-form") body.servedBy = state.user.id;

      if (await mutate(actions[id][0], { method: "POST", body }, actions[id][1])) {
        form.reset();
      }
    } catch (error) {
      toast(error.message);
    }
  }

  async function handleClick(event) {
    const t = event.target;
    const hit = (selector) => t.closest(selector);
    let el;

    if ((el = hit("[data-nav]"))) { state.view = el.dataset.nav; state.query = ""; render(); return; }

    if ((el = hit("[data-login-preset]"))) {
      const [email, password] = credentials[el.dataset.loginPreset];
      document.querySelector("#email").value = email;
      document.querySelector("#password").value = password;
      await login(email, password).catch((error) => toast(error.message));
      return;
    }

    if (hit("[data-logout]")) { logout(); return; }
    if (hit("[data-refresh]")) { await loadData(); toast("Data refreshed"); return; }

    if ((el = hit("[data-pay]"))) {
      const method = document.getElementById(`method-${el.dataset.pay}`).value;
      await mutate("/api/payments/pay", { method: "POST", body: { studentId: el.dataset.student, feeId: el.dataset.pay, method } }, "Payment recorded");
      return;
    }

    if ((el = hit("[data-complaint]"))) {
      const status = el.dataset.next;
      await mutate(`/api/complaints/${el.dataset.complaint}/status`, { method: "PATCH", body: { status, assignedTo: status === "Assigned" ? assignee[el.dataset.category] || "Maintenance Team" : undefined, note: `Status changed to ${status} by ${state.user.name}` } }, "Complaint updated");
      return;
    }

    if ((el = hit("[data-leave]"))) { await mutate(`/api/leaves/${el.dataset.leave}/status`, { method: "PATCH", body: { status: el.dataset.value, reviewedBy: state.user.id } }, `Leave ${el.dataset.value.toLowerCase()}`); return; }
    if ((el = hit("[data-vacate]"))) { await mutate(`/api/allocations/${el.dataset.vacate}/vacate`, { method: "PATCH", body: {} }, "Room vacated"); return; }
    if ((el = hit("[data-maint]"))) { await mutate(`/api/rooms/${encodeURIComponent(el.dataset.maint)}`, { method: "PATCH", body: { underMaintenance: el.dataset.value === "true" } }, "Room updated"); return; }
    if ((el = hit("[data-student-status]"))) { await mutate(`/api/students/${el.dataset.studentStatus}`, { method: "PATCH", body: { status: el.dataset.value } }, "Student updated"); return; }
    if ((el = hit("[data-cancel-reg]"))) { await mutate(`/api/registrations/${el.dataset.cancelReg}/cancel`, { method: "PATCH", body: {} }, "Registration cancelled"); return; }
    if ((el = hit("[data-read]"))) { await mutate(`/api/notifications/${el.dataset.read}/read`, { method: "PATCH", body: {} }, "Marked as read"); return; }

    if (hit("[data-save-attendance]")) {
      const records = [...document.querySelectorAll("[data-att]")].map((select) => ({ studentId: select.dataset.att, status: select.value }));
      state.attDraft = {};
      await mutate("/api/attendance/bulk", { method: "POST", body: { date: state.attDate, records, markedBy: state.user.id } }, `Attendance saved for ${state.attDate}`);
    }
  }

  function handleInput(event) {
    if (event.target.id === "student-search") {
      state.query = event.target.value;
      const q = state.query.toLowerCase();
      document.getElementById("students-table").innerHTML = studentsTable(state.data.students.filter((s) => !q || `${s.name} ${s.rollNo} ${s.email} ${s.course}`.toLowerCase().includes(q)));
    }
  }

  function handleChange(event) {
    const el = event.target;

    if (el.id === "att-date" && el.value) {
      state.attDate = el.value;
      state.attDraft = {};
      render();
    } else if (el.dataset && el.dataset.att) {
      state.attDraft[el.dataset.att] = el.value;
    }
  }

  function render() {
    if (!state.token || !state.user) {
      renderLogin();
      return;
    }

    renderShell();
  }

  document.addEventListener("submit", submitForm);
  document.addEventListener("click", handleClick);
  document.addEventListener("input", handleInput);
  document.addEventListener("change", handleChange);

  if (state.token && state.user) {
    loadData();
  } else {
    render();
  }
})();
