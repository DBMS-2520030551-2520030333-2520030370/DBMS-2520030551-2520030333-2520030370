const crypto = require("crypto");
const fs = require("fs");
const http = require("http");
const path = require("path");
const {
  readBody,
  requestJson,
  sendError,
  sendJson
} = require("../shared/service-kit");

const port = Number(process.env.GATEWAY_PORT || 4000);
const frontendDir = path.join(__dirname, "..", "frontend");
const jwtSecret = process.env.JWT_SECRET || "development-demo-secret";

const services = {
  student: process.env.STUDENT_SERVICE_URL || "http://localhost:4101",
  fee: process.env.FEE_SERVICE_URL || "http://localhost:4102",
  complaint: process.env.COMPLAINT_SERVICE_URL || "http://localhost:4103",
  attendance: process.env.ATTENDANCE_SERVICE_URL || "http://localhost:4104",
  mess: process.env.MESS_SERVICE_URL || "http://localhost:4105",
  notification: process.env.NOTIFICATION_SERVICE_URL || "http://localhost:4106"
};

// Role-based access control enforced at the gateway (the UI also hides restricted screens).
//   read / write : roles allowed for GET / any mutating method
//   own          : students are limited to their own records (studentId is forced by the gateway)
//   studentWrite : mutating routes (by path suffix) a student may still call for their own record
const proxyRules = [
  { prefix: "/api/students", service: "student", target: "/students", read: ["admin", "mess", "student"], write: ["admin"], ownId: true },
  { prefix: "/api/rooms", service: "student", target: "/rooms", read: ["admin", "mess", "student"], write: ["admin"] },
  { prefix: "/api/allocations", service: "student", target: "/allocations", read: ["admin", "student"], write: ["admin"], own: true },
  { prefix: "/api/fees", service: "fee", target: "/fees", read: ["admin", "student"], write: ["admin"], own: true },
  { prefix: "/api/payments", service: "fee", target: "/payments", read: ["admin", "student"], write: ["admin"], own: true },
  { prefix: "/api/receipts", service: "fee", target: "/receipts", read: ["admin", "student"], write: ["admin"] },
  { prefix: "/api/complaints", service: "complaint", target: "/complaints", read: ["admin", "mess", "student"], write: ["admin", "mess"], own: true, studentWrite: [""] },
  { prefix: "/api/attendance", service: "attendance", target: "/attendance", read: ["admin", "student"], write: ["admin"], own: true },
  { prefix: "/api/leaves", service: "attendance", target: "/leaves", read: ["admin", "student"], write: ["admin"], own: true, studentWrite: [""] },
  { prefix: "/api/menu", service: "mess", target: "/menu", read: ["admin", "mess", "student"], write: ["admin", "mess"] },
  { prefix: "/api/registrations", service: "mess", target: "/registrations", read: ["admin", "mess", "student"], write: ["admin", "mess"], own: true, studentWrite: ["", "/cancel"] },
  { prefix: "/api/meal-attendance", service: "mess", target: "/meal-attendance", read: ["admin", "mess"], write: ["admin", "mess"] },
  { prefix: "/api/demand", service: "mess", target: "/demand", read: ["admin", "mess"], write: [] },
  { prefix: "/api/notices", service: "notification", target: "/notices", read: ["admin", "mess", "student"], write: ["admin"] },
  { prefix: "/api/notifications", service: "notification", target: "/notifications", read: ["admin", "mess", "student"], write: ["admin"], own: true, studentWrite: ["/read"] }
].sort((x, y) => y.prefix.length - x.prefix.length);

function base64Url(value) {
  return Buffer.from(value)
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

function fromBase64Url(value) {
  const padded = value.padEnd(value.length + ((4 - (value.length % 4)) % 4), "=");
  return Buffer.from(padded.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
}

function signToken(user) {
  const payload = base64Url(JSON.stringify({
    sub: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    roomNo: user.roomNo,
    exp: Date.now() + 1000 * 60 * 60 * 8
  }));
  const signature = crypto.createHmac("sha256", jwtSecret).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function verifyToken(token) {
  if (!token || !token.includes(".")) {
    return null;
  }

  const [payload, signature] = token.split(".");
  const expected = crypto.createHmac("sha256", jwtSecret).update(payload).digest("base64url");
  const expectedBuffer = Buffer.from(expected);
  const signatureBuffer = Buffer.from(signature);

  if (expectedBuffer.length !== signatureBuffer.length || !crypto.timingSafeEqual(expectedBuffer, signatureBuffer)) {
    return null;
  }

  const parsed = JSON.parse(fromBase64Url(payload));
  if (parsed.exp < Date.now()) {
    return null;
  }

  return parsed;
}

function authUser(req) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice("Bearer ".length) : "";
  return verifyToken(token);
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const types = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg"
  };
  return types[ext] || "application/octet-stream";
}

function serveStatic(req, res, pathname) {
  const requested = pathname === "/" ? "/index.html" : pathname;
  const resolved = path.normalize(path.join(frontendDir, decodeURIComponent(requested)));

  if (!resolved.startsWith(frontendDir)) {
    sendError(res, 403, "Forbidden");
    return;
  }

  const filePath = fs.existsSync(resolved) && fs.statSync(resolved).isFile()
    ? resolved
    : path.join(frontendDir, "index.html");

  fs.readFile(filePath, (error, contents) => {
    if (error) {
      sendError(res, 500, "Unable to read frontend asset");
      return;
    }

    res.writeHead(200, {
      "Content-Type": contentType(filePath),
      "Cache-Control": filePath.endsWith("index.html") ? "no-cache" : "public, max-age=3600"
    });
    res.end(contents);
  });
}

function findProxyRule(pathname) {
  return proxyRules.find((rule) => {
    return pathname === rule.prefix || pathname.startsWith(`${rule.prefix}/`);
  });
}

async function login(req, res) {
  let body;

  try {
    body = await readBody(req);
  } catch (error) {
    sendError(res, 400, error.message);
    return;
  }

  const response = await requestJson(`${services.student}/auth/verify`, {
    method: "POST",
    body
  });

  if (!response.ok) {
    sendJson(res, response.status, response.json);
    return;
  }

  sendJson(res, 200, {
    token: signToken(response.json),
    user: response.json
  });
}

async function serviceStatus(res) {
  const checks = await Promise.all(Object.entries(services).map(async ([name, url]) => {
    try {
      const response = await requestJson(`${url}/health`, { timeoutMs: 1500 });
      return {
        name,
        url,
        ok: response.ok,
        detail: response.json
      };
    } catch (error) {
      return {
        name,
        url,
        ok: false,
        detail: error.message
      };
    }
  }));

  sendJson(res, 200, {
    gateway: "ok",
    services: checks
  });
}

async function overview(res) {
  const stats = {};
  await Promise.all(Object.entries(services).map(async ([name, url]) => {
    try {
      const response = await requestJson(`${url}/stats`, { timeoutMs: 2000 });
      stats[name] = response.ok ? response.json : { service: name, unavailable: true };
    } catch (error) {
      stats[name] = { service: name, unavailable: true, error: error.message };
    }
  }));

  sendJson(res, 200, {
    generatedAt: new Date().toISOString(),
    summary: {
      students: stats.student.studentCount || 0,
      occupiedBeds: stats.student.occupiedBeds || 0,
      totalBeds: stats.student.totalBeds || 0,
      occupancyRate: stats.student.occupancyRate || 0,
      pendingFeeAmount: stats.fee.pendingAmount || 0,
      studentsWithDues: stats.fee.studentsWithDues || 0,
      openComplaints: stats.complaint.openComplaints || 0,
      presentToday: stats.attendance.presentToday || 0,
      pendingLeaves: stats.attendance.pendingLeaves || 0,
      mealsRegisteredToday: stats.mess.registeredToday || 0,
      activeNotices: stats.notification.activeNotices || 0
    },
    stats
  });
}

function authorize(rule, method, suffix, user) {
  const isRead = method === "GET";
  const allowed = isRead ? rule.read : rule.write;

  if (allowed.includes(user.role)) {
    return true;
  }

  return user.role === "student"
    && !isRead
    && (rule.studentWrite || []).some((allowedSuffix) => allowedSuffix === "" ? suffix === "" : suffix.endsWith(allowedSuffix));
}

async function proxy(req, res, parsedUrl, rule, user) {
  const suffix = parsedUrl.pathname.slice(rule.prefix.length);

  if (!authorize(rule, req.method, suffix, user)) {
    sendError(res, 403, `The ${user.role} role is not permitted to ${req.method} ${rule.prefix}`);
    return;
  }

  let body;

  try {
    body = ["POST", "PUT", "PATCH", "DELETE"].includes(req.method) ? await readBody(req) : undefined;
  } catch (error) {
    sendError(res, 400, error.message);
    return;
  }

  const search = new URLSearchParams(parsedUrl.search);

  if (user.role === "student") {
    if (rule.ownId && suffix && decodeURIComponent(suffix.slice(1)) !== user.sub) {
      sendError(res, 403, "Students can only view their own profile");
      return;
    }

    if (rule.ownId && !suffix && req.method === "GET") {
      search.set("studentId", user.sub);
    }

    if (rule.own && req.method === "GET") {
      search.set("studentId", user.sub);
    }

    // Students act only for themselves: the gateway stamps their id on writes and
    // the owning service rejects changes to records that belong to someone else.
    if (rule.own && body) {
      body.studentId = user.sub;
    }
  }

  if (body && req.method === "POST" && !body.recordedBy) {
    body.recordedBy = user.sub;
  }

  const query = search.toString();
  const targetUrl = `${services[rule.service]}${rule.target}${suffix}${query ? `?${query}` : ""}`;

  try {
    const response = await requestJson(targetUrl, {
      method: req.method,
      body,
      headers: { "X-User-Id": user.sub, "X-User-Role": user.role },
      timeoutMs: 6000
    });

    sendJson(res, response.status, response.json);
  } catch (error) {
    sendError(res, 502, `${rule.service} service unavailable`, error.message);
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    sendJson(res, 204, {});
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;

  try {
    if (pathname === "/api/auth/login" && req.method === "POST") {
      await login(req, res);
      return;
    }

    if (pathname === "/api/health") {
      sendJson(res, 200, {
        service: "api-gateway",
        status: "ok",
        checkedAt: new Date().toISOString()
      });
      return;
    }

    if (pathname === "/api/service-status") {
      await serviceStatus(res);
      return;
    }

    if (pathname.startsWith("/api/")) {
      const user = authUser(req);

      if (!user) {
        sendError(res, 401, "Authentication required");
        return;
      }

      if (pathname === "/api/auth/me" && req.method === "GET") {
        sendJson(res, 200, { user });
        return;
      }

      if (pathname === "/api/overview" && req.method === "GET") {
        if (user.role === "student") {
          sendError(res, 403, "The student role is not permitted to view the administration overview");
          return;
        }
        await overview(res);
        return;
      }

      const rule = findProxyRule(pathname);
      if (!rule) {
        sendError(res, 404, "Gateway route not found");
        return;
      }

      await proxy(req, res, parsedUrl, rule, user);
      return;
    }

    serveStatic(req, res, pathname);
  } catch (error) {
    sendError(res, 500, error.message || "Unexpected gateway error");
  }
});

server.listen(port, () => {
  console.log(`api-gateway listening on http://localhost:${port}`);
});
