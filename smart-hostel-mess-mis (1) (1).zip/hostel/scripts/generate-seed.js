// Generates seed.json (and db.json) for every service with dates relative to today,
// so attendance, meals and dues always look current in a demo.
const path = require("path");
const { hashPassword, writeJson } = require("../shared/service-kit");

const servicesDir = path.join(__dirname, "..", "services");
const now = new Date();
const dayOffset = (n) => new Date(now.getTime() + n * 86400000).toISOString().slice(0, 10);
const stamp = (n, time = "09:00") => `${dayOffset(n)}T${time}:00.000Z`;
const weekday = (n) => ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][new Date(`${dayOffset(n)}T00:00:00Z`).getUTCDay()];
const month = dayOffset(0).slice(0, 7);

const students = [
  ["Aarav Sharma", "B.Tech CSE", 2, "Rajesh Sharma"],
  ["Ishita Verma", "B.Tech ECE", 1, "Sunil Verma"],
  ["Rohan Reddy", "B.Tech CSE", 2, "Venkat Reddy"],
  ["Sneha Iyer", "B.Tech IT", 3, "Lakshmi Iyer"],
  ["Karthik Nair", "B.Tech ME", 2, "Suresh Nair"],
  ["Priya Singh", "B.Tech CSE", 1, "Amit Singh"],
  ["Mohammed Faiz", "B.Tech EEE", 3, "Imran Faiz"],
  ["Ananya Das", "B.Tech CSE", 2, "Bikash Das"],
  ["Vikas Patel", "B.Tech CE", 4, "Harish Patel"],
  ["Meera Joshi", "B.Tech IT", 1, "Nitin Joshi"],
  ["Sai Teja", "B.Tech AI&DS", 2, "Ramana Teja"],
  ["Divya Menon", "B.Tech CSE", 1, "Gopal Menon"]
].map(([name, course, year, guardianName], index) => {
  const n = index + 1;
  return {
    id: `stu-${2600 + n}`,
    rollNo: `25200301${String(n).padStart(2, "0")}`,
    name,
    phone: `98765432${String(10 + n).padStart(2, "0")}`,
    email: `${name.split(" ")[0].toLowerCase()}@student.test`,
    password: hashPassword("student123"),
    role: "student",
    course,
    year,
    guardianName,
    guardianPhone: `98000000${String(10 + n).padStart(2, "0")}`,
    status: n === 12 ? "pending" : "active",
    joinedDate: dayOffset(-120 + n)
  };
});

const staff = [
  ["adm-0001", "Dr. Suresh Kumar", "admin@hostel.test", "admin123", "admin", "9000000001"],
  ["msx-0001", "Lakshmi Devi", "mess@hostel.test", "mess123", "mess", "9000000002"]
].map(([id, name, email, password, role, phone]) => ({
  id, rollNo: `STAFF-${id.slice(-4)}`, name, phone, email, password: hashPassword(password), role,
  course: role === "admin" ? "Hostel Administration" : "Mess Administration", year: 0,
  guardianName: "", guardianPhone: "", status: "active", joinedDate: dayOffset(-400)
}));

const rooms = [
  ["A-101", "A", 1, 2], ["A-102", "A", 1, 2], ["A-103", "A", 1, 3], ["A-104", "A", 1, 3],
  ["A-201", "A", 2, 2], ["A-202", "A", 2, 2], ["B-101", "B", 1, 3], ["B-102", "B", 1, 3],
  ["B-201", "B", 2, 2], ["B-202", "B", 2, 4]
].map(([roomNo, block, floor, capacity]) => ({
  roomNo, block, floor, capacity,
  roomType: capacity === 2 ? "Double" : capacity === 3 ? "Triple" : "Dormitory",
  underMaintenance: roomNo === "B-201"
}));

const roomPlan = ["A-101", "A-101", "A-102", "A-102", "A-103", "A-103", "A-104", "B-101", "B-101", "B-102", "B-102"];
const active = students.filter((s) => s.status === "active");
const allocations = active.slice(0, 10).map((student, i) => ({
  id: `alc-${1001 + i}`, studentId: student.id, roomNo: roomPlan[i],
  allocatedOn: dayOffset(-110), vacatedOn: null, status: "Active"
}));
const allocated = allocations.map((a) => a.studentId);

// Fees and payments
const fees = [];
const payments = [];
let receipt = 1;
active.forEach((student, i) => {
  const rent = { id: `fee-r${i + 1}`, studentId: student.id, feeType: "Hostel Rent", amount: 42000, term: "Sem 1 2026-27", dueDate: dayOffset(-40), status: "pending", paymentDate: null, receiptNo: null, notes: "Semester hostel rent" };
  const mess = { id: `fee-m${i + 1}`, studentId: student.id, feeType: "Mess Charges", amount: 3600, term: month, dueDate: dayOffset(i % 3 === 0 ? -3 : 12), status: "pending", paymentDate: null, receiptNo: null, notes: "Monthly mess charges" };
  for (const fee of [rent, mess]) {
    const paid = fee === rent ? i % 4 !== 3 : i % 2 === 1;
    if (paid) {
      const receiptNo = `RCP-${month.replace("-", "")}-${String(receipt++).padStart(4, "0")}`;
      fee.status = "paid";
      fee.paymentDate = stamp(-(20 + i));
      fee.receiptNo = receiptNo;
      payments.push({ id: `pay-${1000 + payments.length + 1}`, studentId: student.id, studentName: student.name, feeId: fee.id, feeType: fee.feeType, term: fee.term, amount: fee.amount, paymentDate: fee.paymentDate, method: ["UPI", "Cash", "Bank Transfer", "Card"][i % 4], recordedBy: "adm-0001", receiptNo });
    }
    fees.push(fee);
  }
});

// Attendance for the last 7 days (today is partly marked so the desk can finish it)
const attendance = [];
allocated.forEach((studentId, i) => {
  for (let d = -7; d <= 0; d += 1) {
    if (d === 0 && i > 5) continue;
    const roll = (i * 7 + Math.abs(d) * 3) % 11;
    const status = roll === 0 ? "Absent" : roll === 1 ? "Late" : "Present";
    attendance.push({ id: `att-${studentId}-${d}`, studentId, date: dayOffset(d), status, remark: "", markedBy: "adm-0001", updatedAt: stamp(d, "21:00") });
  }
});

const leaves = [
  { id: "lve-1001", studentId: "stu-2603", fromDate: dayOffset(2), toDate: dayOffset(4), reason: "Family function", destination: "Warangal", status: "Pending", reviewedBy: null, createdAt: stamp(-1) },
  { id: "lve-1002", studentId: "stu-2605", fromDate: dayOffset(-3), toDate: dayOffset(-1), reason: "Medical checkup", destination: "Kochi", status: "Approved", reviewedBy: "adm-0001", createdAt: stamp(-6) },
  { id: "lve-1003", studentId: "stu-2607", fromDate: dayOffset(5), toDate: dayOffset(6), reason: "Hackathon travel", destination: "Bengaluru", status: "Pending", reviewedBy: null, createdAt: stamp(0, "07:30") }
];

// Weekly mess menu
const menuPlan = {
  Breakfast: ["Idli, sambar, coconut chutney", "Poori and aloo masala", "Upma and banana", "Dosa with tomato chutney", "Pongal and vada", "Paratha with curd", "Bread, omelette or jam, tea"],
  Lunch: ["Rice, dal, cabbage fry, curd", "Veg pulao, raita, papad", "Rice, sambar, beans poriyal", "Chapati, paneer curry, rice", "Rice, rasam, potato fry", "Veg biryani, raita", "Rice, dal tadka, mixed veg curry"],
  Snacks: ["Tea and biscuits", "Samosa and tea", "Sprouts chaat", "Bajji and tea", "Fruit bowl and tea", "Pav bhaji bites", "Corn chaat and tea"],
  Dinner: ["Chapati, dal, aloo gobi", "Rice, sambar, egg curry or paneer", "Fried rice and manchurian", "Chapati, chole", "Rice, dal fry, cauliflower fry", "Chapati, mixed veg, curd rice", "Khichdi and papad"]
};
const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const menu = [];
dayNames.forEach((day, d) => {
  Object.entries(menuPlan).forEach(([mealType, list]) => {
    menu.push({ id: `mnu-${day.slice(0, 3).toLowerCase()}-${mealType.slice(0, 3).toLowerCase()}`, day, mealType, items: list[d], isVeg: !/egg|omelette/.test(list[d]), updatedAt: stamp(-30) });
  });
});

const registrations = [];
const mealAttendance = [];
allocated.forEach((studentId, i) => {
  [0, 1].forEach((offset) => {
    ["Lunch", "Dinner"].forEach((mealType) => {
      if ((i + offset + mealType.length) % 5 !== 0) {
        registrations.push({ id: `reg-${studentId}-${offset}-${mealType}`, studentId, date: dayOffset(offset), mealType, status: "Registered", createdAt: stamp(-1, "18:00") });
      }
    });
  });
  registrations.push({ id: `reg-${studentId}-0-Breakfast`, studentId, date: dayOffset(0), mealType: "Breakfast", status: "Registered", createdAt: stamp(-1, "18:00") });
  if (i % 4 !== 3) {
    mealAttendance.push({ id: `mel-${studentId}-b`, studentId, date: dayOffset(0), mealType: "Breakfast", registered: true, servedBy: "msx-0001", servedAt: stamp(0, "07:45") });
  }
});

const complaints = [
  ["stu-2601", "Water", "No hot water in the block A geyser since yesterday.", "High", "In Progress", "Maintenance Team"],
  ["stu-2604", "Mess", "Dinner was served cold on Tuesday; please review timing.", "Medium", "Assigned", "Mess Committee"],
  ["stu-2606", "Room", "Ceiling fan makes a loud noise at night.", "Low", "Pending", null],
  ["stu-2608", "Internet", "Wi-Fi drops repeatedly on the first floor.", "Medium", "Resolved", "IT Support"],
  ["stu-2610", "Cleaning", "Washroom on B-block first floor needs daily cleaning.", "Medium", "Pending", null]
].map(([studentId, category, description, priority, status, assignedTo], i) => ({
  id: `cmp-${1001 + i}`, studentId, category, description, priority, status, assignedTo,
  createdDate: stamp(-(i + 1), "10:00"), resolvedDate: status === "Resolved" ? stamp(0, "08:00") : null,
  activity: [{ at: stamp(-(i + 1), "10:00"), message: "Complaint submitted" }].concat(assignedTo ? [{ at: stamp(-(i + 1), "12:00"), message: `Assigned to ${assignedTo}` }] : [])
}));

const notices = [
  ["Hostel fee due date", "Semester hostel rent dues must be cleared at the hostel office within the due date to avoid fines.", "Fees", "High", 7],
  ["Special dinner on Sunday", "A festival dinner will be served on Sunday. Register for the meal before Saturday evening.", "Mess", "Medium", 6],
  ["Water tank cleaning", "Water supply will be interrupted from 10:00 to 12:00 tomorrow for overhead tank cleaning.", "Maintenance", "High", 2],
  ["Night attendance timings", "Night attendance is taken at 21:00. Inform the warden in advance if you will be late.", "Hostel", "Medium", 30]
].map(([title, description, category, priority, days], i) => ({
  id: `not-${1001 + i}`, adminId: "adm-0001", title, description, category, priority, audience: "All Students",
  createdDate: stamp(-(i + 1), "12:00"), expiresOn: dayOffset(days)
}));

const notifications = [
  ["stu-2601", "Complaint update", "Your water complaint is now In Progress."],
  ["stu-2603", "Leave request received", "Your leave request is pending warden approval."],
  ["stu-2605", "Leave approved", "Your medical leave request was approved."],
  ["stu-2604", "Fee reminder", "Mess charges for this month are due soon."]
].map(([studentId, title, message], i) => ({ id: `ntf-${1001 + i}`, studentId, title, message, channel: "In App", read: false, createdAt: stamp(-i, "11:00") }));

const seeds = {
  "student-service": { users: [...staff, ...students], rooms, allocations },
  "fee-service": { fees, payments },
  "complaint-service": { complaints },
  "attendance-service": { attendance, leaves },
  "mess-service": { menu, registrations, mealAttendance },
  "notification-service": { notices, notifications }
};

for (const [service, data] of Object.entries(seeds)) {
  writeJson(path.join(servicesDir, service, "seed.json"), data);
  writeJson(path.join(servicesDir, service, "db.json"), data);
  console.log(`Seeded ${service}`);
}
