// Restores every service database to fresh demo data (dates are relative to today).
require("./generate-seed");
