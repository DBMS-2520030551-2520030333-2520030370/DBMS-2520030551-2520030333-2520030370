const { spawn } = require("child_process");
const http = require("http");
const path = require("path");
const { requestJson } = require("../shared/service-kit");

const rootDir = path.join(__dirname, "..");
const gateway = "http://localhost:4000";
let child;
let passed = 0;

function check(condition, label) {
  if (!condition) {
    throw new Error(`FAILED: ${label}`);
  }
  passed += 1;
  console.log(`  ok  ${label}`);
}

async function waitForGateway() {
  const deadline = Date.now() + 12000;

  while (Date.now() < deadline) {
    try {
      const response = await requestJson(`${gateway}/api/service-status`, { timeoutMs: 1000 });
      if (response.ok && response.json.services.every((service) => service.ok)) {
        return;
      }
    } catch (error) {
      // gateway not up yet
    }
    await new Promise((resolve) => setTimeout(resolve, 300));
  }

  throw new Error("Gateway or services did not become ready");
}

async function login(email, password) {
  const response = await requestJson(`${gateway}/api/auth/login`, { method: "POST", body: { email, password } });
  return response;
}

const call = (token, url, method = "GET", body) =>
  requestJson(`${gateway}${url}`, { method, body, headers: { Authorization: `Bearer ${token}` } });

async function run() {
  child = spawn(process.execPath, [path.join(rootDir, "scripts", "start-all.js")], { cwd: rootDir, stdio: ["ignore", "pipe", "pipe"] });
  child.stdout.on("data", () => {});
  child.stderr.on("data", (chunk) => process.stderr.write(chunk));

  await waitForGateway();
  console.log("Authentication");
  check((await login("admin@hostel.test", "wrong")).status === 401, "wrong password is rejected");
  const admin = await login("admin@hostel.test", "admin123");
  const student = await login("aarav@student.test", "student123");
  const mess = await login("mess@hostel.test", "mess123");
  check(admin.ok && student.ok && mess.ok, "admin, student and mess staff can sign in");
  const A = admin.json.token;
  const S = student.json.token;
  const M = mess.json.token;
  check((await requestJson(`${gateway}/api/students`)).status === 401, "requests without a token get 401");

  console.log("Student and room management");
  check((await call(A, "/api/overview")).json.summary.students >= 11, "overview aggregates all services");
  const dup = await call(A, "/api/students", "POST", { name: "X", rollNo: "2520030101", phone: "9999999999", email: "x@student.test", course: "CSE" });
  check(dup.status === 409, "duplicate roll number is rejected");
  const badPhone = await call(A, "/api/students", "POST", { name: "X", rollNo: "999", phone: "12", email: "y@student.test", course: "CSE" });
  check(badPhone.status === 400, "invalid phone number is rejected");
  const created = await call(A, "/api/students", "POST", { name: "Test Student", rollNo: "2520039999", phone: "9123456780", email: "test@student.test", course: "B.Tech CSE", year: 1 });
  check(created.status === 201 && created.json.password === undefined, "student registered without leaking the password");
  const full = await call(A, "/api/allocations", "POST", { studentId: created.json.id, roomNo: "A-101" });
  check(full.status === 409, "allocation to a full room is rejected");
  const maint = await call(A, "/api/allocations", "POST", { studentId: created.json.id, roomNo: "B-201" });
  check(maint.status === 409, "allocation to a room under maintenance is rejected");
  const ok = await call(A, "/api/allocations", "POST", { studentId: created.json.id, roomNo: "B-202" });
  check(ok.status === 201, "valid room allocation succeeds");
  check((await call(A, "/api/allocations", "POST", { studentId: created.json.id, roomNo: "B-202" })).status === 409, "double allocation is rejected");
  check((await call(A, `/api/allocations/${ok.json.id}/vacate`, "PATCH", {})).ok, "room can be vacated");

  console.log("Fees");
  const fee = await call(A, "/api/fees", "POST", { studentId: created.json.id, feeType: "Hostel Rent", amount: 1000, term: "Smoke", dueDate: "2099-01-01" });
  check(fee.status === 201, "fee record created");
  check((await call(A, "/api/fees", "POST", { studentId: created.json.id, feeType: "Hostel Rent", amount: -5, term: "Smoke2", dueDate: "2099-01-01" })).status === 400, "negative fee amount is rejected");
  const pay = await call(A, "/api/payments/pay", "POST", { studentId: created.json.id, feeId: fee.json.id, method: "UPI" });
  check(pay.status === 201 && pay.json.receiptNo, "payment recorded with receipt");
  check((await call(A, "/api/payments/pay", "POST", { studentId: created.json.id, feeId: fee.json.id, method: "UPI" })).status === 409, "paying twice is rejected");

  console.log("Attendance");
  const today = new Date().toISOString().slice(0, 10);
  check((await call(A, "/api/attendance", "POST", { studentId: "stu-2601", date: "2099-01-01", status: "Present" })).status === 400, "future attendance is rejected");
  check((await call(A, "/api/attendance/bulk", "POST", { date: today, records: [{ studentId: "stu-2609", status: "Present" }, { studentId: "stu-2610", status: "Absent" }] })).status === 201, "bulk attendance saved");
  const leave = await call(S, "/api/leaves", "POST", { fromDate: "2099-02-01", toDate: "2099-02-03", reason: "Smoke test", destination: "Home" });
  check(leave.status === 201 && leave.json.studentId === "stu-2601", "student can request leave (id stamped by gateway)");
  check((await call(S, "/api/leaves", "POST", { fromDate: "2099-02-02", toDate: "2099-02-04", reason: "Overlap" })).status === 409, "overlapping leave is rejected");
  check((await call(A, `/api/leaves/${leave.json.id}/status`, "PATCH", { status: "Approved" })).ok, "admin approves leave");

  console.log("Mess");
  const day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][new Date(Date.now() + 86400000).getUTCDay()];
  const menu = await call(S, "/api/menu");
  check(menu.ok && menu.json.length === 28, "student can view the weekly menu");
  const tomorrow = new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10);
  const reg = await call(S, "/api/registrations", "POST", { date: tomorrow, mealType: "Breakfast" });
  check(reg.status === 201, "student registers for a meal");
  check((await call(S, "/api/registrations", "POST", { date: tomorrow, mealType: "Breakfast" })).status === 409, "duplicate meal registration is rejected");
  check((await call(M, `/api/demand?date=${tomorrow}`)).json.meals.Breakfast.registered >= 1, "mess staff can see meal demand");
  check((await call(M, "/api/meal-attendance", "POST", { studentId: "stu-2609", mealType: "Dinner" })).status === 201, "mess staff records a served meal");
  console.log(`  (menu check for ${day} ok)`);

  console.log("Complaints and notices");
  const complaint = await call(S, "/api/complaints", "POST", { category: "Room", description: "Smoke test complaint", priority: "Low" });
  check(complaint.status === 201 && complaint.json.studentId === "stu-2601", "student raises complaint");
  check((await call(A, `/api/complaints/${complaint.json.id}/status`, "PATCH", { status: "Resolved" })).ok, "admin resolves complaint");
  check((await call(A, "/api/notices", "POST", { adminId: "adm-0001", title: "Smoke", description: "Notice" })).status === 201, "admin publishes notice");

  console.log("Role-based access control");
  const ownList = await call(S, "/api/students");
  check(ownList.ok && ownList.json.length === 1 && ownList.json[0].id === "stu-2601", "student list is limited to the student's own record");
  check((await call(S, "/api/students/stu-2602")).status === 403, "student cannot view another profile");
  check((await call(S, "/api/students/stu-2601")).ok, "student can view own profile");
  check((await call(S, "/api/overview")).status === 403, "student cannot open the admin overview");
  check((await call(S, "/api/payments/pay", "POST", { feeId: "x", method: "Cash" })).status === 403, "student cannot record payments");
  check((await call(S, "/api/fees")).json.every((item) => item.studentId === "stu-2601"), "student sees only own fees");
  check((await call(S, "/api/attendance")).json.every((item) => item.studentId === "stu-2601"), "student sees only own attendance");
  check((await call(M, "/api/fees")).status === 403, "mess staff cannot view fees");
  check((await call(M, "/api/menu", "POST", { day: "Monday", mealType: "Lunch", items: "x" })).status === 409, "duplicate menu slot is rejected");
  const other = (await call(A, "/api/registrations?studentId=stu-2609")).json.find((r) => r.status === "Registered" && r.date >= today);
  check(other && (await call(S, `/api/registrations/${other.id}/cancel`, "PATCH", {})).status === 403, "student cannot cancel another student's meal");

  const frontend = await new Promise((resolve, reject) => {
    http.get(gateway, (response) => {
      let body = "";
      response.on("data", (chunk) => { body += chunk; });
      response.on("end", () => resolve({ status: response.statusCode, body }));
    }).on("error", reject);
  });
  check(frontend.status === 200 && frontend.body.includes("app-root"), "frontend is served by the gateway");
  console.log(`\nSmoke test passed (${passed} checks).`);
}

run()
  .catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  })
  .finally(() => {
    if (child && !child.killed) {
      child.kill("SIGTERM");
    }
  });
