const { spawn } = require("child_process");
const path = require("path");

const fs = require("fs");

const rootDir = path.join(__dirname, "..");

// First run (no databases yet): create demo data with dates relative to today.
if (!fs.existsSync(path.join(rootDir, "services", "student-service", "db.json"))) {
  require("./generate-seed");
}

const services = [
  ["student-service", "services/student-service/server.js"],
  ["fee-service", "services/fee-service/server.js"],
  ["complaint-service", "services/complaint-service/server.js"],
  ["attendance-service", "services/attendance-service/server.js"],
  ["mess-service", "services/mess-service/server.js"],
  ["notification-service", "services/notification-service/server.js"],
  ["api-gateway", "gateway/server.js"]
];

const env = {
  ...process.env,
  GATEWAY_PORT: process.env.GATEWAY_PORT || "4000",
  STUDENT_SERVICE_PORT: process.env.STUDENT_SERVICE_PORT || "4101",
  FEE_SERVICE_PORT: process.env.FEE_SERVICE_PORT || "4102",
  COMPLAINT_SERVICE_PORT: process.env.COMPLAINT_SERVICE_PORT || "4103",
  ATTENDANCE_SERVICE_PORT: process.env.ATTENDANCE_SERVICE_PORT || "4104",
  MESS_SERVICE_PORT: process.env.MESS_SERVICE_PORT || "4105",
  NOTIFICATION_SERVICE_PORT: process.env.NOTIFICATION_SERVICE_PORT || "4106",
  STUDENT_SERVICE_URL: process.env.STUDENT_SERVICE_URL || "http://localhost:4101",
  FEE_SERVICE_URL: process.env.FEE_SERVICE_URL || "http://localhost:4102",
  COMPLAINT_SERVICE_URL: process.env.COMPLAINT_SERVICE_URL || "http://localhost:4103",
  ATTENDANCE_SERVICE_URL: process.env.ATTENDANCE_SERVICE_URL || "http://localhost:4104",
  MESS_SERVICE_URL: process.env.MESS_SERVICE_URL || "http://localhost:4105",
  NOTIFICATION_SERVICE_URL: process.env.NOTIFICATION_SERVICE_URL || "http://localhost:4106",
  JWT_SECRET: process.env.JWT_SECRET || "development-demo-secret"
};

const children = services.map(([name, script]) => {
  const child = spawn(process.execPath, [path.join(rootDir, script)], {
    cwd: rootDir,
    env,
    stdio: ["ignore", "pipe", "pipe"]
  });

  child.stdout.on("data", (chunk) => process.stdout.write(`[${name}] ${chunk}`));
  child.stderr.on("data", (chunk) => process.stderr.write(`[${name}] ${chunk}`));
  child.on("exit", (code) => {
    if (code !== 0 && code !== null) {
      console.error(`[${name}] exited with code ${code}`);
    }
  });

  return child;
});

function shutdown() {
  for (const child of children) {
    if (!child.killed) {
      child.kill("SIGTERM");
    }
  }
}

process.on("SIGINT", () => { shutdown(); process.exit(0); });
process.on("SIGTERM", () => { shutdown(); process.exit(0); });

console.log("Smart Hostel and Mess Administration MIS starting...");
console.log(`Open http://localhost:${env.GATEWAY_PORT}`);
