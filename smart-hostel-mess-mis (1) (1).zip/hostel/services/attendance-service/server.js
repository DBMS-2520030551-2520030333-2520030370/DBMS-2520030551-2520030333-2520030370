const path = require("path");
const {
  createId,
  createService,
  nowIso,
  requireFields,
  today
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.ATTENDANCE_SERVICE_PORT || 4104);
const attendanceStatuses = ["Present", "Absent", "Late", "On Leave"];
const leaveStatuses = ["Pending", "Approved", "Rejected", "Cancelled"];
const isDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value)) && !Number.isNaN(Date.parse(value));

function upsert(db, { studentId, date, status, remark, markedBy }) {
  const existing = db.attendance.find((item) => item.studentId === studentId && item.date === date);

  if (existing) {
    existing.status = status;
    existing.remark = remark || "";
    existing.markedBy = markedBy || existing.markedBy;
    existing.updatedAt = nowIso();
    return existing;
  }

  const record = {
    id: createId("att"),
    studentId,
    date,
    status,
    remark: remark || "",
    markedBy: markedBy || "system",
    updatedAt: nowIso()
  };
  db.attendance.push(record);
  return record;
}

function countBy(records) {
  const counts = { Present: 0, Absent: 0, Late: 0, "On Leave": 0 };
  for (const record of records) {
    counts[record.status] += 1;
  }
  return counts;
}

function stats(db) {
  const todays = db.attendance.filter((item) => item.date === today());
  const counts = countBy(todays);

  return {
    service: "attendance-service",
    date: today(),
    markedToday: todays.length,
    presentToday: counts.Present + counts.Late,
    absentToday: counts.Absent,
    onLeaveToday: counts["On Leave"],
    pendingLeaves: db.leaves.filter((item) => item.status === "Pending").length,
    approvedLeaves: db.leaves.filter((item) => item.status === "Approved").length,
    recordCount: db.attendance.length
  };
}

createService({
  name: "attendance-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "GET",
      path: "/attendance",
      handler: ({ db, query, send }) => {
        const list = db.attendance
          .filter((item) => !query.studentId || item.studentId === query.studentId)
          .filter((item) => !query.date || item.date === query.date)
          .filter((item) => !query.from || item.date >= query.from)
          .filter((item) => !query.to || item.date <= query.to)
          .filter((item) => !query.status || item.status === query.status)
          .sort((a, b) => b.date.localeCompare(a.date));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/attendance",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "date", "status"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!isDate(body.date)) {
          error(400, "Date must use the YYYY-MM-DD format");
          return;
        }

        if (body.date > today()) {
          error(400, "Attendance cannot be marked for a future date");
          return;
        }

        if (!attendanceStatuses.includes(body.status)) {
          error(400, `Status must be one of: ${attendanceStatuses.join(", ")}`);
          return;
        }

        const record = upsert(db, body);
        save();
        send(201, record);
      }
    },
    {
      method: "POST",
      path: "/attendance/bulk",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["date", "records"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!isDate(body.date) || body.date > today()) {
          error(400, "Date must be a valid, non-future YYYY-MM-DD date");
          return;
        }

        if (!Array.isArray(body.records) || !body.records.length) {
          error(400, "records must be a non-empty array");
          return;
        }

        const invalid = body.records.find((item) => !item.studentId || !attendanceStatuses.includes(item.status));
        if (invalid) {
          error(400, "Every record needs a studentId and a valid status");
          return;
        }

        const saved = body.records.map((item) => upsert(db, { ...item, date: body.date, markedBy: body.markedBy }));
        save();
        send(201, { date: body.date, saved: saved.length, counts: countBy(saved) });
      }
    },
    {
      method: "GET",
      path: "/attendance/summary",
      handler: ({ db, query, send }) => {
        const date = query.date || today();
        const records = db.attendance.filter((item) => item.date === date);
        send(200, { date, total: records.length, counts: countBy(records) });
      }
    },
    {
      method: "GET",
      path: "/attendance/summary/:studentId",
      handler: ({ db, params, query, send }) => {
        const records = db.attendance
          .filter((item) => item.studentId === params.studentId)
          .filter((item) => !query.from || item.date >= query.from)
          .filter((item) => !query.to || item.date <= query.to);
        const counts = countBy(records);
        const attended = counts.Present + counts.Late;
        const considered = records.length - counts["On Leave"];

        send(200, {
          studentId: params.studentId,
          days: records.length,
          counts,
          attendancePercentage: considered > 0 ? Math.round((attended / considered) * 100) : 100
        });
      }
    },
    {
      method: "GET",
      path: "/leaves",
      handler: ({ db, query, send }) => {
        const list = db.leaves
          .filter((item) => !query.studentId || item.studentId === query.studentId)
          .filter((item) => !query.status || item.status === query.status)
          .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/leaves",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "fromDate", "toDate", "reason"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!isDate(body.fromDate) || !isDate(body.toDate) || body.toDate < body.fromDate) {
          error(400, "Leave dates must be valid and the end date cannot precede the start date");
          return;
        }

        const overlap = db.leaves.find((item) => {
          return item.studentId === body.studentId
            && ["Pending", "Approved"].includes(item.status)
            && body.fromDate <= item.toDate
            && item.fromDate <= body.toDate;
        });

        if (overlap) {
          error(409, "An active leave request already covers part of these dates", { conflictId: overlap.id });
          return;
        }

        const leave = {
          id: createId("lve"),
          studentId: body.studentId,
          fromDate: body.fromDate,
          toDate: body.toDate,
          reason: body.reason.trim(),
          destination: body.destination || "",
          status: "Pending",
          reviewedBy: null,
          createdAt: nowIso()
        };

        db.leaves.push(leave);
        save();
        send(201, leave);
      }
    },
    {
      method: "PATCH",
      path: "/leaves/:id/status",
      handler: ({ db, params, body, save, send, error }) => {
        const leave = db.leaves.find((item) => item.id === params.id);

        if (!leave) {
          error(404, "Leave request not found");
          return;
        }

        if (!leaveStatuses.includes(body.status)) {
          error(400, `Status must be one of: ${leaveStatuses.join(", ")}`);
          return;
        }

        leave.status = body.status;
        leave.reviewedBy = body.reviewedBy || leave.reviewedBy;
        leave.reviewedAt = nowIso();
        save();
        send(200, leave);
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => send(200, stats(db))
    }
  ]
});
