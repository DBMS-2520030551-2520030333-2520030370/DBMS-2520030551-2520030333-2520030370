const path = require("path");
const {
  createId,
  createService,
  nowIso,
  requireFields
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.COMPLAINT_SERVICE_PORT || 4103);
const validStatuses = ["Pending", "Assigned", "In Progress", "Resolved"];

function complaintStats(db) {
  const byStatus = validStatuses.reduce((accumulator, status) => {
    accumulator[status] = db.complaints.filter((item) => item.status === status).length;
    return accumulator;
  }, {});

  return {
    service: "complaint-service",
    complaintCount: db.complaints.length,
    openComplaints: db.complaints.filter((item) => item.status !== "Resolved").length,
    resolvedComplaints: byStatus.Resolved,
    highPriority: db.complaints.filter((item) => item.priority === "High" && item.status !== "Resolved").length,
    byStatus
  };
}

function filterComplaints(complaints, query) {
  return complaints.filter((complaint) => {
    const residentMatch = !query.studentId || complaint.studentId === query.studentId;
    const statusMatch = !query.status || complaint.status === query.status;
    const categoryMatch = !query.category || complaint.category === query.category;
    return residentMatch && statusMatch && categoryMatch;
  });
}

createService({
  name: "complaint-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "GET",
      path: "/complaints",
      handler: ({ db, query, send }) => {
        const complaints = filterComplaints(db.complaints, query)
          .sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));
        send(200, complaints);
      }
    },
    {
      method: "GET",
      path: "/complaints/:id",
      handler: ({ db, params, send, error }) => {
        const complaint = db.complaints.find((item) => item.id === params.id);

        if (!complaint) {
          error(404, "Complaint not found");
          return;
        }

        send(200, complaint);
      }
    },
    {
      method: "POST",
      path: "/complaints",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "category", "description"]);
        } catch (validationError) {
          error(validationError.statusCode || 400, validationError.message);
          return;
        }

        const createdAt = nowIso();
        const complaint = {
          id: createId("cmp"),
          studentId: body.studentId,
          category: body.category,
          description: body.description.trim(),
          priority: body.priority || "Medium",
          status: "Pending",
          assignedTo: null,
          createdDate: createdAt,
          resolvedDate: null,
          activity: [
            {
              at: createdAt,
              message: "Complaint submitted"
            }
          ]
        };

        db.complaints.push(complaint);
        save();
        send(201, complaint);
      }
    },
    {
      method: "PATCH",
      path: "/complaints/:id/assign",
      handler: ({ db, params, body, save, send, error }) => {
        const complaint = db.complaints.find((item) => item.id === params.id);

        if (!complaint) {
          error(404, "Complaint not found");
          return;
        }

        if (!body.assignedTo) {
          error(400, "assignedTo is required");
          return;
        }

        complaint.assignedTo = body.assignedTo;
        complaint.status = "Assigned";
        complaint.activity.push({
          at: nowIso(),
          message: `Assigned to ${body.assignedTo}`
        });

        save();
        send(200, complaint);
      }
    },
    {
      method: "PATCH",
      path: "/complaints/:id/status",
      handler: ({ db, params, body, save, send, error }) => {
        const complaint = db.complaints.find((item) => item.id === params.id);

        if (!complaint) {
          error(404, "Complaint not found");
          return;
        }

        if (!validStatuses.includes(body.status)) {
          error(400, `Status must be one of: ${validStatuses.join(", ")}`);
          return;
        }

        complaint.status = body.status;

        if (body.assignedTo !== undefined) {
          complaint.assignedTo = body.assignedTo;
        }

        if (body.status === "Resolved") {
          complaint.resolvedDate = nowIso();
        } else {
          complaint.resolvedDate = null;
        }

        complaint.activity.push({
          at: nowIso(),
          message: body.note || `Status changed to ${body.status}`
        });

        save();
        send(200, complaint);
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => {
        send(200, complaintStats(db));
      }
    }
  ]
});
