const path = require("path");
const {
  clone,
  createId,
  createService,
  nowIso,
  replaceObject,
  requestJson,
  requireFields,
  today
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.FEE_SERVICE_PORT || 4102);
const studentServiceUrl = process.env.STUDENT_SERVICE_URL || "http://localhost:4101";
const feeTypes = ["Hostel Rent", "Mess Charges", "Security Deposit", "Electricity", "Fine", "Other"];

// A pending fee whose due date has passed is reported as overdue.
function effectiveStatus(fee) {
  if (fee.status === "pending" && fee.dueDate < today()) {
    return "overdue";
  }
  return fee.status;
}

function view(fee) {
  return { ...fee, status: effectiveStatus(fee) };
}

function filtered(items, query) {
  return items.filter((item) => {
    return (!query.studentId || item.studentId === query.studentId)
      && (!query.status || (item.status ? effectiveStatus(item) : item.status) === query.status)
      && (!query.feeType || item.feeType === query.feeType)
      && (!query.term || item.term === query.term);
  });
}

function receiptNumber(studentId) {
  const short = studentId.replace(/[^0-9]/g, "").slice(-4).padStart(4, "0");
  return `RCP-${nowIso().slice(0, 7).replace("-", "")}-${short}-${Date.now().toString(36).toUpperCase()}`;
}

function feeStats(db) {
  const fees = db.fees.map(view);
  const unpaid = fees.filter((fee) => fee.status !== "paid");

  return {
    service: "fee-service",
    totalBilled: fees.reduce((sum, fee) => sum + Number(fee.amount), 0),
    totalCollected: db.payments.reduce((sum, payment) => sum + Number(payment.amount), 0),
    pendingAmount: unpaid.reduce((sum, fee) => sum + Number(fee.amount), 0),
    pendingFees: fees.filter((fee) => fee.status === "pending").length,
    overdueFees: fees.filter((fee) => fee.status === "overdue").length,
    studentsWithDues: new Set(unpaid.map((fee) => fee.studentId)).size,
    receiptCount: db.payments.length
  };
}

async function verifyStudent(studentId) {
  const response = await requestJson(`${studentServiceUrl}/students/${encodeURIComponent(studentId)}`);

  if (!response.ok) {
    throw Object.assign(new Error(response.status === 404 ? "Student not found" : "Student service unavailable"), {
      statusCode: response.status === 404 ? 400 : 503
    });
  }

  return response.json;
}

createService({
  name: "fee-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "GET",
      path: "/fees",
      handler: ({ db, query, send }) => {
        send(200, filtered(db.fees, query).map(view).sort((a, b) => a.dueDate.localeCompare(b.dueDate)));
      }
    },
    {
      method: "POST",
      path: "/fees",
      handler: async ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "feeType", "amount", "term", "dueDate"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!feeTypes.includes(body.feeType)) {
          error(400, `Fee type must be one of: ${feeTypes.join(", ")}`);
          return;
        }

        if (!(Number(body.amount) > 0)) {
          error(400, "Amount must be a positive number");
          return;
        }

        try {
          await verifyStudent(body.studentId);
        } catch (verificationError) {
          error(verificationError.statusCode || 503, verificationError.message);
          return;
        }

        if (db.fees.some((fee) => fee.studentId === body.studentId && fee.feeType === body.feeType && fee.term === body.term)) {
          error(409, "This fee has already been raised for the student and term");
          return;
        }

        const fee = {
          id: createId("fee"),
          studentId: body.studentId,
          feeType: body.feeType,
          amount: Number(body.amount),
          term: body.term,
          dueDate: body.dueDate,
          status: "pending",
          paymentDate: null,
          receiptNo: null,
          notes: body.notes || ""
        };

        db.fees.push(fee);
        save();
        send(201, view(fee));
      }
    },
    {
      method: "PATCH",
      path: "/fees/:id",
      handler: ({ db, params, body, save, send, error }) => {
        const fee = db.fees.find((item) => item.id === params.id);

        if (!fee) {
          error(404, "Fee record not found");
          return;
        }

        if (fee.status === "paid") {
          error(409, "A paid fee cannot be edited");
          return;
        }

        for (const field of ["amount", "dueDate", "notes"]) {
          if (body[field] !== undefined) {
            fee[field] = field === "amount" ? Number(body[field]) : body[field];
          }
        }

        save();
        send(200, view(fee));
      }
    },
    {
      method: "GET",
      path: "/payments",
      handler: ({ db, query, send }) => {
        const list = filtered(db.payments, query).sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
        send(200, list);
      }
    },
    {
      method: "GET",
      path: "/payments/pending/:studentId",
      handler: ({ db, params, send }) => {
        const fees = db.fees.filter((fee) => fee.studentId === params.studentId && fee.status !== "paid").map(view);
        send(200, {
          studentId: params.studentId,
          pendingAmount: fees.reduce((sum, fee) => sum + Number(fee.amount), 0),
          fees
        });
      }
    },
    {
      method: "POST",
      path: "/payments/pay",
      handler: async ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "feeId", "method"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        let student;
        try {
          student = await verifyStudent(body.studentId);
        } catch (verificationError) {
          error(verificationError.statusCode || 503, verificationError.message);
          return;
        }

        // Snapshot gives all-or-nothing behaviour, mirroring a database transaction.
        const snapshot = clone(db);

        try {
          const fee = db.fees.find((item) => item.id === body.feeId);

          if (!fee) {
            throw Object.assign(new Error("Fee record not found"), { statusCode: 404 });
          }

          if (fee.studentId !== body.studentId) {
            throw Object.assign(new Error("Fee does not belong to this student"), { statusCode: 400 });
          }

          if (fee.status === "paid") {
            throw Object.assign(new Error("Fee is already paid"), { statusCode: 409 });
          }

          const paidAt = nowIso();
          const receiptNo = receiptNumber(body.studentId);
          const payment = {
            id: createId("pay"),
            studentId: body.studentId,
            studentName: student.name,
            feeId: fee.id,
            feeType: fee.feeType,
            term: fee.term,
            amount: Number(fee.amount),
            paymentDate: paidAt,
            method: body.method,
            recordedBy: body.recordedBy || "admin",
            receiptNo
          };

          db.payments.push(payment);
          fee.status = "paid";
          fee.paymentDate = paidAt;
          fee.receiptNo = receiptNo;

          save();
          send(201, payment);
        } catch (paymentError) {
          replaceObject(db, snapshot);
          error(paymentError.statusCode || 500, paymentError.message);
        }
      }
    },
    {
      method: "GET",
      path: "/receipts/:paymentId",
      handler: ({ db, params, send, error }) => {
        const payment = db.payments.find((item) => item.id === params.paymentId || item.receiptNo === params.paymentId);

        if (!payment) {
          error(404, "Receipt not found");
          return;
        }

        send(200, payment);
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => send(200, feeStats(db))
    }
  ]
});
