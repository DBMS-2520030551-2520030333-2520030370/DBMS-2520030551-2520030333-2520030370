const path = require("path");
const {
  createId,
  createService,
  nowIso,
  requireFields,
  today
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.MESS_SERVICE_PORT || 4105);
const mealTypes = ["Breakfast", "Lunch", "Snacks", "Dinner"];
const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const isDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value)) && !Number.isNaN(Date.parse(value));

function dayName(date) {
  return days[new Date(`${date}T00:00:00Z`).getUTCDay()];
}

function demand(db, date) {
  const result = {};

  for (const meal of mealTypes) {
    const registered = db.registrations.filter((item) => item.date === date && item.mealType === meal && item.status === "Registered").length;
    const attended = db.mealAttendance.filter((item) => item.date === date && item.mealType === meal).length;
    result[meal] = { registered, attended };
  }

  return { date, day: dayName(date), meals: result };
}

function stats(db) {
  const todayDemand = demand(db, today());
  const meals = Object.values(todayDemand.meals);

  return {
    service: "mess-service",
    date: today(),
    menuItems: db.menu.length,
    registeredToday: meals.reduce((sum, item) => sum + item.registered, 0),
    servedToday: meals.reduce((sum, item) => sum + item.attended, 0),
    todayDemand: todayDemand.meals
  };
}

createService({
  name: "mess-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "GET",
      path: "/menu",
      handler: ({ db, query, send }) => {
        const list = db.menu
          .filter((item) => !query.day || item.day === query.day)
          .filter((item) => !query.mealType || item.mealType === query.mealType)
          .sort((a, b) => days.indexOf(a.day) - days.indexOf(b.day) || mealTypes.indexOf(a.mealType) - mealTypes.indexOf(b.mealType));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/menu",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["day", "mealType", "items"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!days.includes(body.day) || !mealTypes.includes(body.mealType)) {
          error(400, "Invalid day or meal type");
          return;
        }

        if (db.menu.some((item) => item.day === body.day && item.mealType === body.mealType)) {
          error(409, "A menu already exists for this day and meal; edit it instead");
          return;
        }

        const entry = {
          id: createId("mnu"),
          day: body.day,
          mealType: body.mealType,
          items: body.items.trim(),
          isVeg: body.isVeg === undefined ? true : String(body.isVeg) !== "false",
          updatedAt: nowIso()
        };

        db.menu.push(entry);
        save();
        send(201, entry);
      }
    },
    {
      method: "PATCH",
      path: "/menu/:id",
      handler: ({ db, params, body, save, send, error }) => {
        const entry = db.menu.find((item) => item.id === params.id);

        if (!entry) {
          error(404, "Menu entry not found");
          return;
        }

        if (body.items !== undefined) {
          entry.items = String(body.items).trim();
        }

        if (body.isVeg !== undefined) {
          entry.isVeg = String(body.isVeg) !== "false";
        }

        entry.updatedAt = nowIso();
        save();
        send(200, entry);
      }
    },
    {
      method: "GET",
      path: "/registrations",
      handler: ({ db, query, send }) => {
        const list = db.registrations
          .filter((item) => !query.studentId || item.studentId === query.studentId)
          .filter((item) => !query.date || item.date === query.date)
          .filter((item) => !query.mealType || item.mealType === query.mealType)
          .filter((item) => !query.status || item.status === query.status)
          .sort((a, b) => b.date.localeCompare(a.date));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/registrations",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "date", "mealType"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!isDate(body.date) || !mealTypes.includes(body.mealType)) {
          error(400, "Invalid date or meal type");
          return;
        }

        if (body.date < today()) {
          error(400, "Meals cannot be registered for a past date");
          return;
        }

        if (!db.menu.some((item) => item.day === dayName(body.date) && item.mealType === body.mealType)) {
          error(409, `No ${body.mealType} is scheduled on ${dayName(body.date)}`);
          return;
        }

        const existing = db.registrations.find((item) => {
          return item.studentId === body.studentId && item.date === body.date && item.mealType === body.mealType;
        });

        if (existing && existing.status === "Registered") {
          error(409, "Already registered for this meal");
          return;
        }

        if (existing) {
          existing.status = "Registered";
          existing.createdAt = nowIso();
          save();
          send(201, existing);
          return;
        }

        const registration = {
          id: createId("reg"),
          studentId: body.studentId,
          date: body.date,
          mealType: body.mealType,
          status: "Registered",
          createdAt: nowIso()
        };

        db.registrations.push(registration);
        save();
        send(201, registration);
      }
    },
    {
      method: "PATCH",
      path: "/registrations/:id/cancel",
      handler: ({ db, params, body, save, send, error }) => {
        const registration = db.registrations.find((item) => item.id === params.id);

        if (!registration) {
          error(404, "Registration not found");
          return;
        }

        if (body.studentId && registration.studentId !== body.studentId) {
          error(403, "You can only cancel your own registrations");
          return;
        }

        if (registration.date < today()) {
          error(409, "Past registrations cannot be cancelled");
          return;
        }

        registration.status = "Cancelled";
        save();
        send(200, registration);
      }
    },
    {
      method: "GET",
      path: "/meal-attendance",
      handler: ({ db, query, send }) => {
        const list = db.mealAttendance
          .filter((item) => !query.studentId || item.studentId === query.studentId)
          .filter((item) => !query.date || item.date === query.date)
          .filter((item) => !query.mealType || item.mealType === query.mealType)
          .sort((a, b) => b.servedAt.localeCompare(a.servedAt));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/meal-attendance",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "mealType"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        const date = body.date || today();

        if (!mealTypes.includes(body.mealType) || date > today()) {
          error(400, "Invalid meal type or future date");
          return;
        }

        if (db.mealAttendance.some((item) => item.studentId === body.studentId && item.date === date && item.mealType === body.mealType)) {
          error(409, "Meal already recorded for this student");
          return;
        }

        const registered = db.registrations.some((item) => {
          return item.studentId === body.studentId && item.date === date && item.mealType === body.mealType && item.status === "Registered";
        });

        const record = {
          id: createId("mel"),
          studentId: body.studentId,
          date,
          mealType: body.mealType,
          registered,
          servedBy: body.servedBy || "mess staff",
          servedAt: nowIso()
        };

        db.mealAttendance.push(record);
        save();
        send(201, record);
      }
    },
    {
      method: "GET",
      path: "/demand",
      handler: ({ db, query, send, error }) => {
        const date = query.date || today();

        if (!isDate(date)) {
          error(400, "Date must use the YYYY-MM-DD format");
          return;
        }

        send(200, demand(db, date));
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => send(200, stats(db))
    }
  ]
});
