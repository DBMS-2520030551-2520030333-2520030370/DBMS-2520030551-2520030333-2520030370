const path = require("path");
const {
  createId,
  createService,
  nowIso,
  requireFields
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.NOTIFICATION_SERVICE_PORT || 4106);

function notificationStats(db) {
  return {
    service: "notification-service",
    noticeCount: db.notices.length,
    activeNotices: db.notices.filter((notice) => !notice.expiresOn || notice.expiresOn >= nowIso().slice(0, 10)).length,
    unreadNotifications: db.notifications.filter((notification) => !notification.read).length,
    notificationCount: db.notifications.length
  };
}

createService({
  name: "notification-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "GET",
      path: "/notices",
      handler: ({ db, query, send }) => {
        const notices = db.notices.filter((notice) => {
          const priorityMatch = !query.priority || notice.priority === query.priority;
          const categoryMatch = !query.category || notice.category === query.category;
          return priorityMatch && categoryMatch;
        });

        send(200, notices.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate)));
      }
    },
    {
      method: "POST",
      path: "/notices",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["adminId", "title", "description"]);
        } catch (validationError) {
          error(validationError.statusCode || 400, validationError.message);
          return;
        }

        const notice = {
          id: createId("not"),
          adminId: body.adminId,
          title: body.title.trim(),
          description: body.description.trim(),
          category: body.category || "General",
          priority: body.priority || "Medium",
          audience: body.audience || "All Students",
          createdDate: nowIso(),
          expiresOn: body.expiresOn || null
        };

        db.notices.push(notice);
        save();
        send(201, notice);
      }
    },
    {
      method: "PATCH",
      path: "/notices/:id",
      handler: ({ db, params, body, save, send, error }) => {
        const notice = db.notices.find((item) => item.id === params.id);

        if (!notice) {
          error(404, "Notice not found");
          return;
        }

        for (const field of ["title", "description", "category", "priority", "audience", "expiresOn"]) {
          if (body[field] !== undefined) {
            notice[field] = body[field];
          }
        }

        save();
        send(200, notice);
      }
    },
    {
      method: "GET",
      path: "/notifications",
      handler: ({ db, query, send }) => {
        const notifications = db.notifications.filter((notification) => {
          const residentMatch = !query.studentId || notification.studentId === query.studentId;
          const readMatch = query.read === undefined || String(notification.read) === query.read;
          return residentMatch && readMatch;
        });

        send(200, notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
      }
    },
    {
      method: "POST",
      path: "/notifications",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "title", "message"]);
        } catch (validationError) {
          error(validationError.statusCode || 400, validationError.message);
          return;
        }

        const notification = {
          id: createId("ntf"),
          studentId: body.studentId,
          title: body.title.trim(),
          message: body.message.trim(),
          channel: body.channel || "In App",
          read: false,
          createdAt: nowIso()
        };

        db.notifications.push(notification);
        save();
        send(201, notification);
      }
    },
    {
      method: "PATCH",
      path: "/notifications/:id/read",
      handler: ({ db, params, body, save, send, error }) => {
        const notification = db.notifications.find((item) => item.id === params.id);

        if (!notification) {
          error(404, "Notification not found");
          return;
        }

        if (body.studentId && notification.studentId !== body.studentId) {
          error(403, "You can only update your own notifications");
          return;
        }

        notification.read = true;
        save();
        send(200, notification);
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => {
        send(200, notificationStats(db));
      }
    }
  ]
});
