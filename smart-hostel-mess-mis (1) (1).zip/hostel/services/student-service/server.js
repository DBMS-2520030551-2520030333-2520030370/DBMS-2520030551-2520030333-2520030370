const path = require("path");
const {
  byId,
  createId,
  createService,
  requireFields,
  today,
  verifyPassword,
  hashPassword
} = require("../../shared/service-kit");

const dataFile = path.join(__dirname, "db.json");
const seedFile = path.join(__dirname, "seed.json");
const port = Number(process.env.STUDENT_SERVICE_PORT || 4101);

const studentFields = ["name", "phone", "email", "course", "year", "guardianName", "guardianPhone", "status"];

function safe(user) {
  const { password, ...rest } = user;
  return rest;
}

function activeAllocation(db, studentId) {
  return db.allocations.find((item) => item.studentId === studentId && item.status === "Active") || null;
}

function occupancy(db, room) {
  const occupied = db.allocations.filter((item) => item.roomNo === room.roomNo && item.status === "Active").length;
  let status = "Available";

  if (room.underMaintenance) {
    status = "Maintenance";
  } else if (occupied >= room.capacity) {
    status = "Full";
  }

  return { ...room, occupied, vacant: Math.max(0, room.capacity - occupied), status };
}

function withRoom(db, student) {
  const allocation = activeAllocation(db, student.id);
  return { ...safe(student), roomNo: allocation ? allocation.roomNo : null };
}

function stats(db) {
  const students = db.users.filter((user) => user.role === "student");
  const rooms = db.rooms.map((room) => occupancy(db, room));
  const beds = rooms.filter((room) => room.status !== "Maintenance").reduce((sum, room) => sum + room.capacity, 0);
  const occupied = rooms.reduce((sum, room) => sum + room.occupied, 0);

  return {
    service: "student-service",
    studentCount: students.length,
    activeStudents: students.filter((student) => student.status === "active").length,
    pendingRegistrations: students.filter((student) => student.status === "pending").length,
    roomCount: rooms.length,
    totalBeds: beds,
    occupiedBeds: occupied,
    vacantBeds: Math.max(0, beds - occupied),
    occupancyRate: beds ? Math.round((occupied / beds) * 100) : 0,
    unallocatedStudents: students.filter((student) => student.status === "active" && !activeAllocation(db, student.id)).length
  };
}

createService({
  name: "student-service",
  port,
  dataFile,
  seedFile,
  routes: [
    {
      method: "POST",
      path: "/auth/verify",
      handler: ({ db, body, send, error }) => {
        try {
          requireFields(body, ["email", "password"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        const user = db.users.find((item) => item.email.toLowerCase() === String(body.email).toLowerCase());

        if (!user || !verifyPassword(body.password, user.password)) {
          error(401, "Invalid email or password");
          return;
        }

        if (user.status === "vacated") {
          error(403, "This account is no longer active");
          return;
        }

        send(200, withRoom(db, user));
      }
    },
    {
      method: "GET",
      path: "/students",
      handler: ({ db, query, send }) => {
        const list = db.users
          .filter((user) => user.role === "student")
          .filter((user) => !query.status || user.status === query.status)
          .filter((user) => {
            const text = `${user.name} ${user.rollNo} ${user.email} ${user.course}`.toLowerCase();
            return !query.q || text.includes(String(query.q).toLowerCase());
          })
          .filter((user) => !query.studentId || user.id === query.studentId)
          .map((user) => withRoom(db, user))
          .sort((a, b) => a.rollNo.localeCompare(b.rollNo));
        send(200, list);
      }
    },
    {
      method: "GET",
      path: "/students/:id",
      handler: ({ db, params, send, error }) => {
        const student = byId(db.users, params.id);
        if (!student) {
          error(404, "Student not found");
          return;
        }
        send(200, withRoom(db, student));
      }
    },
    {
      method: "POST",
      path: "/students",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["name", "rollNo", "phone", "email", "course"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (!/^\d{10}$/.test(String(body.phone))) {
          error(400, "Phone number must contain 10 digits");
          return;
        }

        if (db.users.some((user) => user.email.toLowerCase() === String(body.email).toLowerCase())) {
          error(409, "A user with this email already exists");
          return;
        }

        if (db.users.some((user) => user.rollNo === String(body.rollNo).trim())) {
          error(409, "A student with this roll number already exists");
          return;
        }

        const student = {
          id: createId("stu"),
          rollNo: String(body.rollNo).trim(),
          name: body.name.trim(),
          phone: body.phone,
          email: body.email.trim().toLowerCase(),
          password: hashPassword(body.password || "student123"),
          role: "student",
          course: body.course,
          year: Number(body.year || 1),
          guardianName: body.guardianName || "",
          guardianPhone: body.guardianPhone || "",
          status: body.status || "active",
          joinedDate: today()
        };

        db.users.push(student);
        save();
        send(201, withRoom(db, student));
      }
    },
    {
      method: "PATCH",
      path: "/students/:id",
      handler: ({ db, params, body, save, send, error }) => {
        const student = db.users.find((item) => item.id === params.id && item.role === "student");

        if (!student) {
          error(404, "Student not found");
          return;
        }

        for (const field of studentFields) {
          if (body[field] !== undefined) {
            student[field] = field === "year" ? Number(body[field]) : body[field];
          }
        }

        if (body.password) {
          student.password = hashPassword(body.password);
        }

        save();
        send(200, withRoom(db, student));
      }
    },
    {
      method: "GET",
      path: "/rooms",
      handler: ({ db, query, send }) => {
        const rooms = db.rooms
          .map((room) => occupancy(db, room))
          .filter((room) => !query.block || room.block === query.block)
          .filter((room) => !query.status || room.status === query.status)
          .sort((a, b) => a.roomNo.localeCompare(b.roomNo));
        send(200, rooms);
      }
    },
    {
      method: "POST",
      path: "/rooms",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["roomNo", "block", "floor", "capacity"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        if (db.rooms.some((room) => room.roomNo === body.roomNo)) {
          error(409, "Room already exists");
          return;
        }

        if (Number(body.capacity) < 1 || Number(body.capacity) > 6) {
          error(400, "Room capacity must be between 1 and 6");
          return;
        }

        const room = {
          roomNo: body.roomNo.trim(),
          block: body.block,
          floor: Number(body.floor),
          capacity: Number(body.capacity),
          roomType: body.roomType || "Standard",
          underMaintenance: false
        };

        db.rooms.push(room);
        save();
        send(201, occupancy(db, room));
      }
    },
    {
      method: "PATCH",
      path: "/rooms/:roomNo",
      handler: ({ db, params, body, save, send, error }) => {
        const room = db.rooms.find((item) => item.roomNo === params.roomNo);

        if (!room) {
          error(404, "Room not found");
          return;
        }

        if (body.capacity !== undefined) {
          const occupied = occupancy(db, room).occupied;
          if (Number(body.capacity) < occupied) {
            error(409, `Capacity cannot be lower than current occupancy (${occupied})`);
            return;
          }
          room.capacity = Number(body.capacity);
        }

        if (body.underMaintenance !== undefined) {
          room.underMaintenance = Boolean(body.underMaintenance);
        }

        for (const field of ["roomType", "block", "floor"]) {
          if (body[field] !== undefined) {
            room[field] = field === "floor" ? Number(body[field]) : body[field];
          }
        }

        save();
        send(200, occupancy(db, room));
      }
    },
    {
      method: "GET",
      path: "/allocations",
      handler: ({ db, query, send }) => {
        const list = db.allocations
          .filter((item) => !query.studentId || item.studentId === query.studentId)
          .filter((item) => !query.roomNo || item.roomNo === query.roomNo)
          .filter((item) => !query.status || item.status === query.status)
          .sort((a, b) => b.allocatedOn.localeCompare(a.allocatedOn));
        send(200, list);
      }
    },
    {
      method: "POST",
      path: "/allocations",
      handler: ({ db, body, save, send, error }) => {
        try {
          requireFields(body, ["studentId", "roomNo"]);
        } catch (validationError) {
          error(400, validationError.message);
          return;
        }

        const student = db.users.find((item) => item.id === body.studentId && item.role === "student");
        const room = db.rooms.find((item) => item.roomNo === body.roomNo);

        if (!student) {
          error(404, "Student not found");
          return;
        }

        if (!room) {
          error(404, "Room not found");
          return;
        }

        if (student.status !== "active") {
          error(409, "Only active students can be allocated a room");
          return;
        }

        if (activeAllocation(db, student.id)) {
          error(409, "Student already has an active room allocation; vacate or transfer first");
          return;
        }

        const current = occupancy(db, room);
        if (current.status === "Maintenance") {
          error(409, "Room is under maintenance");
          return;
        }

        if (current.vacant < 1) {
          error(409, "Room is full");
          return;
        }

        const allocation = {
          id: createId("alc"),
          studentId: student.id,
          roomNo: room.roomNo,
          allocatedOn: body.allocatedOn || today(),
          vacatedOn: null,
          status: "Active"
        };

        db.allocations.push(allocation);
        save();
        send(201, allocation);
      }
    },
    {
      method: "PATCH",
      path: "/allocations/:id/vacate",
      handler: ({ db, params, save, send, error }) => {
        const allocation = db.allocations.find((item) => item.id === params.id);

        if (!allocation) {
          error(404, "Allocation not found");
          return;
        }

        if (allocation.status !== "Active") {
          error(409, "Allocation is already closed");
          return;
        }

        allocation.status = "Vacated";
        allocation.vacatedOn = today();
        save();
        send(200, allocation);
      }
    },
    {
      method: "GET",
      path: "/stats",
      handler: ({ db, send }) => send(200, stats(db))
    }
  ]
});
